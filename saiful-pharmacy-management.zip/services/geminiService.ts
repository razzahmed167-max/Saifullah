
import { GoogleGenAI, Type } from "@google/genai";
import { Medicine, SaleItem, SaleRecord, Expense, ServiceRecord, PurchaseRecord } from "../types";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const getInventoryInsights = async (medicines: Medicine[]) => {
  const ai = getAIClient();
  const inventorySummary = medicines.map(m => `${m.name} (${m.stock} left, expires ${m.expiryDate})`).join(', ');
  
  const prompt = `
    Analyze the following pharmacy inventory data and provide business insights. 
    Focus on:
    1. Stock risks (low quantities).
    2. Expiry warnings.
    3. Suggestions for restocking.
    
    Data: ${inventorySummary}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional pharmaceutical business consultant for Saiful Pharmacy in Shyamnagar. Give concise, actionable advice.",
      }
    });
    return response.text || "No insights available at the moment.";
  } catch (error) {
    console.error("AI Insight Error:", error);
    return "Failed to fetch AI insights.";
  }
};

export const getFinancialAdvice = async (
  sales: SaleRecord[], 
  expenses: Expense[], 
  services: ServiceRecord[],
  medicines: Medicine[],
  purchases: PurchaseRecord[]
) => {
  const ai = getAIClient();
  
  // Calculate Category Performance
  const categorySales: Record<string, number> = {};
  const itemPerformance: Record<string, { revenue: number, units: number, category: string, price: number }> = {};
  
  sales.forEach(sale => {
    if (sale.status === 'returned') return;
    sale.items.forEach(item => {
      const med = medicines.find(m => m.id === item.medicineId);
      const cat = med?.category || 'Uncategorized';
      categorySales[cat] = (categorySales[cat] || 0) + item.total;
      
      if (!itemPerformance[item.medicineId]) {
        itemPerformance[item.medicineId] = { revenue: 0, units: 0, category: cat, price: item.pricePerUnit };
      }
      itemPerformance[item.medicineId].revenue += item.total;
      itemPerformance[item.medicineId].units += item.quantity;
    });
  });

  // Calculate Margin Insights (estimate from latest purchase)
  const margins = medicines.map(m => {
    const latestPurchase = purchases.filter(p => p.medicineId === m.id).pop();
    if (!latestPurchase) return null;
    const unitCost = latestPurchase.costPrice / latestPurchase.quantity;
    const margin = m.price - unitCost;
    const marginPercent = (margin / m.price) * 100;
    return { name: m.name, margin: marginPercent, unitsSold: itemPerformance[m.id]?.units || 0 };
  }).filter(Boolean);

  const stats = {
    revenue: sales.reduce((a, b) => a + (b.status !== 'returned' ? b.totalAmount : 0), 0),
    expenseTotal: expenses.reduce((a, b) => a + b.amount, 0),
    serviceCom: services.reduce((a, b) => a + b.commission, 0),
    topCategories: Object.entries(categorySales).sort((a, b) => b[1] - a[1]).slice(0, 3),
    lowCategories: Object.entries(categorySales).sort((a, b) => a[1] - b[1]).slice(0, 2),
    highMarginItems: margins.sort((a: any, b: any) => b.margin - a.margin).slice(0, 3)
  };

  const prompt = `
    Conduct a deep financial audit for Saiful Pharmacy.
    Financial Snapshot:
    - Revenue: ৳${stats.revenue}
    - Total Expenses: ৳${stats.expenseTotal}
    - Service Commissions: ৳${stats.serviceCom}
    
    Category Insights:
    - Best Performing: ${stats.topCategories.map(c => `${c[0]} (৳${c[1]})`).join(', ')}
    - Underperforming: ${stats.lowCategories.map(c => `${c[0]} (৳${c[1]})`).join(', ')}
    
    Margin Analysis:
    - Top Margin Products: ${stats.highMarginItems.map((i: any) => `${i.name} (${i.margin.toFixed(1)}% margin)`).join(', ')}
    
    TASKS:
    1. Identify which high-margin medicines are popular and suggest how to cross-sell them.
    2. Analyze the underperforming categories and provide a reason why they might be lagging.
    3. Suggest 2 targeted promotional campaigns (Discounts, Bundles, or Loyalty rewards) specifically designed to boost sales for low-velocity items.
    
    Keep the advice highly strategic, focused on increasing the net profit margin of the pharmacy.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a Senior Retail Strategist and Financial Auditor. Focus on margin maximization and inventory turnover.",
      }
    });
    return response.text;
  } catch (error) {
    return "Financial strategy analysis unavailable.";
  }
};

export interface ReorderSuggestion {
  medicineId: string;
  name: string;
  suggestedQuantity: number;
  reason: string;
  supplierRecommendation: string;
  priority: 'High' | 'Medium' | 'Low';
  estimatedCost?: number;
  type: 'Low Stock' | 'Expired Replacement';
  bulkDiscountPotential: string;
  negotiationPoints: string;
}

export const getReorderSuggestions = async (medicines: Medicine[], sales: SaleRecord[]): Promise<ReorderSuggestion[]> => {
  const ai = getAIClient();
  const today = new Date();
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(today.getDate() - 30);

  const velocity: Record<string, number> = {};
  sales.forEach(sale => {
    const saleDate = new Date(sale.date);
    if (saleDate >= thirtyDaysAgo) {
      sale.items.forEach(item => {
        velocity[item.medicineId] = (velocity[item.medicineId] || 0) + item.quantity;
      });
    }
  });

  const criticalItems = medicines.filter(m => {
    const isLow = m.stock < 100;
    const isExpired = new Date(m.expiryDate) < today;
    const isHighVelocityRisk = (velocity[m.id] && m.stock < velocity[m.id] * 1.5);
    return isLow || isExpired || isHighVelocityRisk;
  });
  
  if (criticalItems.length === 0) return [];

  const inventoryContext = criticalItems.map(m => {
    const isExpired = new Date(m.expiryDate) < today;
    return `- ${m.name} (${m.genericName}): Status: ${isExpired ? 'EXPIRED' : 'Low Stock'}, Current Stock: ${m.stock}, Price: ৳${m.price}, Expiry: ${m.expiryDate}, Sales (Last 30d): ${velocity[m.id] || 0}`;
  }).join('\n');

  const prompt = `
    Analyze these critical pharmacy items (Low Stock & Expired) and generate a specific reorder plan for Saiful Pharmacy.
    
    SPECIAL TASK:
    Identify multiple items from the same supplier to leverage for bulk discounts. 
    For each item, provide:
    1. Bulk Discount Potential: Specify if ordering this along with other items from the same brand (e.g. Square, Incepta) could trigger a price reduction.
    2. Negotiation Points: Provide 1-2 sharp points the pharmacist can use when talking to the supplier representative (e.g. "Order volume is up 20%", "Competitive pricing from other brand").

    Guidelines:
    1. For EXPIRED items: Suggest immediate full stock replacement.
    2. For LOW STOCK: Suggest quantity to cover 45-60 days of sales.
    3. Potential Suppliers: Square Pharmaceuticals, Incepta, Beximco, Renata, ACME, SK+F, or Aristopharma.
    4. Assign Priority: 'High', 'Medium', 'Low'.

    Context:
    ${inventoryContext}
    
    Return JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              medicineId: { type: Type.STRING },
              name: { type: Type.STRING },
              suggestedQuantity: { type: Type.NUMBER },
              reason: { type: Type.STRING },
              supplierRecommendation: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
              estimatedCost: { type: Type.NUMBER },
              type: { type: Type.STRING, enum: ['Low Stock', 'Expired Replacement'] },
              bulkDiscountPotential: { type: Type.STRING, description: "Leverage for grouping orders" },
              negotiationPoints: { type: Type.STRING, description: " pharmacist talking points" }
            },
            required: ['name', 'suggestedQuantity', 'reason', 'supplierRecommendation', 'priority', 'type', 'bulkDiscountPotential', 'negotiationPoints']
          }
        },
        systemInstruction: "Expert pharmaceutical supply chain manager focusing on cost optimization and negotiation.",
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};

export const getHealthAdvice = async (query: string) => {
  const ai = getAIClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: query,
      config: {
        systemInstruction: "You are a pharmaceutical assistant at Saiful Pharmacy. Provide medicine info with a medical disclaimer.",
      }
    });
    return response.text;
  } catch (error) {
    return "Failed to process request.";
  }
};

export const batchGetMedicineDescriptions = async (meds: Medicine[]): Promise<Record<string, string>> => {
  if (meds.length === 0) return {};
  const ai = getAIClient();
  const medList = meds.map(m => `ID: ${m.id}, Name: ${m.name}, Generic: ${m.genericName}`).join('\n');
  
  const prompt = `Provide professional 1-sentence descriptions for these medicines.
  Focus on common usage and important warnings.
  
  Medicines:
  ${medList}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          description: "A map where keys are medicine IDs and values are their descriptions.",
          properties: meds.reduce((acc, med) => ({
            ...acc,
            [med.id]: { type: Type.STRING, description: `Description for ${med.name}` }
          }), {})
        }
      }
    });
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Batch description error:", error);
    return {};
  }
};

export const getComplementarySuggestions = async (cartItems: SaleItem[], allMedicines: Medicine[]): Promise<string[]> => {
  if (cartItems.length === 0) return [];
  const ai = getAIClient();
  const cartDesc = cartItems.map(i => i.name).join(", ");
  const availableMeds = allMedicines.map(m => ({ id: m.id, name: m.name })).slice(0, 15);

  const prompt = `Cart: [${cartDesc}]. Suggest 2-3 matching medicine IDs from: ${JSON.stringify(availableMeds)}. Return JSON array.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return [];
  }
};
