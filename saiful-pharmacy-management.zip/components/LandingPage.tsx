
import React, { useState, useEffect } from 'react';
import { Medicine, Language, MedicineRequest, PharmacySettings } from '../types';
import { TRANSLATIONS, HEALTH_TIPS, PROMO_OFFERS, TRUSTED_BRANDS, PHARMACY_STATS } from '../constants';

interface LandingPageProps {
  medicines: Medicine[];
  settings: PharmacySettings;
  onAdminLogin: () => void;
  language: Language;
  onLanguageToggle: () => void;
  onSubmitRequest: (req: Omit<MedicineRequest, 'id' | 'date' | 'status'>) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ medicines, settings, onAdminLogin, language, onLanguageToggle, onSubmitRequest }) => {
  const [search, setSearch] = useState('');
  const [showRequest, setShowRequest] = useState(false);
  const [reqForm, setReqForm] = useState({ name: '', phone: '', med: '', msg: '' });
  const [scrolled, setScrolled] = useState(false);
  const [activeOfferIndex, setActiveOfferIndex] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-playing carousel for Hot Offers
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveOfferIndex((prev) => (prev + 1) % PROMO_OFFERS.length);
    }, 4000); // Change every 4 seconds
    return () => clearInterval(timer);
  }, []);

  const t = TRANSLATIONS[language];
  const filtered = medicines.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase()) || 
    m.genericName.toLowerCase().includes(search.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitRequest({ customerName: reqForm.name, phone: reqForm.phone, medicineName: reqForm.med, message: reqForm.msg });
    alert(language === 'bn' ? 'আপনার অনুরোধ গ্রহণ করা হয়েছে!' : 'Request submitted successfully!');
    setReqForm({ name: '', phone: '', med: '', msg: '' });
    setShowRequest(false);
  };

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900 overflow-x-hidden">
      
      {/* Floating Island Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-700 px-4 pt-4`}>
        <div className={`max-w-md mx-auto h-20 rounded-[2.5rem] flex items-center justify-between px-6 transition-all duration-700 ${scrolled ? 'bg-white/95 backdrop-blur-3xl shadow-2xl border border-white/50' : 'bg-white/40 backdrop-blur-md border border-white/20'}`}>
          <div onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})} className="flex items-center gap-3 cursor-pointer group">
            {/* New Premium Squircle Logo */}
            <div className={`w-12 h-12 rounded-[1.25rem] flex items-center justify-center font-black text-xl transition-all duration-500 group-hover:rotate-6 relative overflow-hidden ${scrolled ? 'bg-emerald-600 text-white shadow-emerald-200 shadow-lg' : 'bg-gray-900 text-white shadow-xl'}`}>
               <div className="shimmer-bar animate-shimmer opacity-20"></div>
               <span className="relative z-10">S</span>
            </div>
            <div>
              <span className="block font-black text-[15px] leading-none tracking-tight text-gray-900">
                {language === 'bn' ? 'সাইফুল ফার্মাসি' : settings.name}
              </span>
              <span className="text-[9px] font-black uppercase tracking-[0.25em] mt-1.5 block text-emerald-600">Premium Care</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onLanguageToggle} className="px-4 py-2.5 rounded-2xl bg-gray-900/5 hover:bg-gray-900/10 transition-all text-[10px] font-black text-gray-600 tracking-widest uppercase">
              {language === 'en' ? 'BN' : 'EN'}
            </button>
            <button onClick={onAdminLogin} className="w-12 h-12 flex items-center justify-center bg-gray-900 text-white rounded-[1.25rem] shadow-2xl active:scale-90 transition-all">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" /></svg>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section: Mesh Gradient & Immersive Graphics */}
      <section className="relative pt-32 pb-12 px-4">
        <div className="max-w-md mx-auto bg-white rounded-[4rem] p-10 relative overflow-hidden carved-shadow border border-white/80">
           {/* Animated Mesh Background Components */}
           <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-100 rounded-full blur-[80px] opacity-40 animate-pulse"></div>
           <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-blue-100 rounded-full blur-[80px] opacity-40 animate-pulse delay-700"></div>
           
           <div className="relative z-10 text-center">
              <div className="inline-flex items-center gap-2 bg-emerald-50 px-5 py-2.5 rounded-full mb-10 border border-emerald-100/50">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                <span className="text-[9px] font-black text-emerald-700 uppercase tracking-[0.4em]">Club More • Atulia</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl font-black mb-8 leading-[1.05] tracking-tighter text-gray-900">
                {language === 'bn' ? (
                  <>আপনার <span className="text-emerald-600 text-gradient">সুস্বাস্থ্যই</span> আমাদের অঙ্গীকার</>
                ) : (
                  <>Elite <span className="text-emerald-600 text-gradient">Pharmacy</span> & Digital Hub</>
                )}
              </h1>
              
              <p className="text-gray-500 text-[15px] font-medium leading-relaxed mb-10 max-w-[300px] mx-auto opacity-70">
                {language === 'bn' ? 'উন্নত মানের ঔষধ ও দ্রুত ডিজিটাল সেবা এখন অতুলিয়ার সবচেয়ে আধুনিক ফার্মাসিতে।' : 'Experience the pinnacle of pharmaceutical care and instant digital transactions in Atulia.'}
              </p>

              <div className="flex flex-col gap-4">
                 <button onClick={() => scrollTo('catalog')} className="bg-gray-900 text-white py-6 rounded-[2rem] font-black text-xs uppercase tracking-[0.3em] shadow-2xl shadow-gray-200 active:scale-95 transition-all">
                    {language === 'bn' ? 'ঔষধের তালিকা' : 'Browse Inventory'}
                 </button>
                 <button onClick={() => setShowRequest(true)} className="bg-white text-emerald-700 py-5 rounded-[2rem] font-black text-[11px] uppercase tracking-[0.3em] active:scale-95 transition-all border-2 border-emerald-50">
                    {t.requestMed}
                 </button>
              </div>
           </div>
        </div>
      </section>

      {/* Trust Stats Bar */}
      <section className="px-6 mb-12">
        <div className="max-w-md mx-auto grid grid-cols-3 gap-3">
          {PHARMACY_STATS.map((stat, i) => (
            <div key={i} className="bg-white/60 backdrop-blur-md p-4 rounded-3xl border border-white/80 text-center">
              <p className="text-xl font-black text-gray-900 tracking-tighter">{stat.value}</p>
              <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">
                {language === 'bn' ? stat.labelBn : stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Hot Offers: Smooth Auto-Playing Carousel */}
      <section className="mb-12">
        <div className="max-w-md mx-auto px-6 flex justify-between items-end mb-6">
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">{language === 'bn' ? 'সেরা অফার' : 'Hot Offers'}</h2>
          <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full">Special Promo</span>
        </div>
        
        <div className="max-w-md mx-auto px-6 relative h-64">
           {PROMO_OFFERS.map((offer, index) => (
             <div 
               key={offer.id} 
               className={`absolute inset-0 transition-all duration-1000 ease-in-out transform flex flex-col justify-center items-start bg-gradient-to-br from-emerald-600 to-emerald-800 p-10 rounded-[3rem] text-white shadow-2xl shadow-emerald-100/50 overflow-hidden mx-6 ${index === activeOfferIndex ? 'opacity-100 translate-x-0 scale-100 z-10' : 'opacity-0 translate-x-8 scale-95 z-0'}`}
             >
                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-400/10 rounded-full blur-xl -ml-12 -mb-12"></div>
                
                <div className="relative z-10">
                   <span className="text-[9px] font-black uppercase tracking-[0.4em] text-emerald-300 mb-3 block">Promotion {index + 1}</span>
                   <h3 className="text-3xl font-black mb-3 tracking-tight leading-none">{language === 'bn' ? offer.titleBn : offer.title}</h3>
                   <p className="text-sm opacity-80 font-medium mb-8 max-w-[200px] leading-snug">{language === 'bn' ? offer.descBn : offer.desc}</p>
                   <button className="bg-white text-emerald-700 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg active:scale-95 transition-transform">
                      {language === 'bn' ? 'বিস্তারিত দেখুন' : 'Explore Now'}
                   </button>
                </div>
             </div>
           ))}
           
           {/* Carousel Progress Indicators */}
           <div className="absolute -bottom-4 left-0 right-0 flex justify-center gap-2">
              {PROMO_OFFERS.map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1.5 rounded-full transition-all duration-500 ${i === activeOfferIndex ? 'w-8 bg-emerald-600' : 'w-2 bg-gray-200'}`}
                ></div>
              ))}
           </div>
        </div>
      </section>

      {/* Quick Access Service Hub */}
      <section id="services" className="max-w-md mx-auto px-6 py-12">
        <div className="flex flex-col items-center mb-10">
           <h2 className="text-3xl font-black text-gray-900 tracking-tight">{t.services}</h2>
           <div className="w-12 h-1.5 bg-emerald-600/10 rounded-full mt-4"></div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <PremiumServiceTile icon="💊" title={t.medicineSales} desc="Catalog" theme="emerald" onClick={() => scrollTo('catalog')} />
          <PremiumServiceTile icon="📡" title={t.recharge} desc="Top-up" theme="blue" />
          <PremiumServiceTile icon="💸" title={t.bkash} desc="Cash Out" theme="pink" />
          <PremiumServiceTile icon="🏦" title={t.nagad} desc="Instant" theme="orange" />
        </div>
      </section>

      {/* PHARMACY CATALOG: 2-COLUMN GRID */}
      <section id="catalog" className="max-w-md mx-auto px-6 py-20 bg-white rounded-t-[5rem] shadow-[0_-20px_50px_rgba(0,0,0,0.02)] relative overflow-hidden">
        <div className="text-center mb-12">
           <span className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.5em] mb-4 inline-block">Pharmacy Catalog</span>
           <h2 className="text-4xl font-black text-gray-900 tracking-tighter">{t.featured}</h2>
        </div>
        
        <div className="relative mb-10 group">
          <input 
            type="text" 
            placeholder={t.searchMed}
            className="w-full bg-slate-50 border-2 border-transparent rounded-3xl px-12 py-5 pl-14 shadow-inner outline-none focus:border-emerald-500/20 focus:bg-white transition-all font-bold text-gray-800 placeholder:text-gray-300 text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="absolute left-6 top-5 text-emerald-600 opacity-40">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:gap-6">
          {filtered.map(med => (
            <div key={med.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group overflow-hidden flex flex-col h-full">
              <div className="relative aspect-square w-full overflow-hidden bg-slate-50">
                 {med.image ? (
                   <img src={med.image} alt={med.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                 ) : (
                   <div className="w-full h-full flex items-center justify-center text-emerald-200 bg-emerald-50/20">
                     <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" /></svg>
                   </div>
                 )}
                 <div className="absolute top-3 right-3 bg-gray-950/80 backdrop-blur-md text-white px-3 py-1.5 rounded-2xl shadow-lg border border-white/10 group-hover:scale-110 transition-transform">
                    <span className="text-[13px] font-black">৳{med.price}</span>
                 </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-black text-gray-900 text-base tracking-tight leading-tight group-hover:text-emerald-700 transition-colors truncate">{med.name}</h3>
                  <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest mt-1.5 truncate">{med.genericName}</p>
                </div>
                <div className="mt-5 flex items-center justify-between">
                   <span className="bg-emerald-50 text-emerald-700 text-[8px] font-black px-2.5 py-1 rounded-full border border-emerald-100 uppercase">{med.category}</span>
                   <button onClick={() => setShowRequest(true)} className="w-9 h-9 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-100 active:scale-90">
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" /></svg>
                   </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Trusted Brands: Logo Cloud */}
      <section className="bg-white py-20 px-6">
        <div className="max-w-md mx-auto">
           <p className="text-center text-[10px] font-black text-gray-300 uppercase tracking-[0.4em] mb-12">Trusted Manufacturers</p>
           <div className="grid grid-cols-4 gap-6 grayscale opacity-40 hover:grayscale-0 transition-all duration-700">
              {TRUSTED_BRANDS.map((brand, i) => (
                <div key={i} className="flex items-center justify-center text-[10px] font-black tracking-tighter text-gray-800 border border-gray-100 py-3 rounded-xl">
                  {brand}
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* Wellness Hub: Advanced Health Cards */}
      <section id="wellness" className="bg-gray-950 py-32 px-6 rounded-t-[6rem] -mt-12">
        <div className="max-w-md mx-auto">
          <h2 className="text-4xl font-black text-white mb-6 text-center tracking-tight">{t.healthTips}</h2>
          <p className="text-[11px] text-emerald-400 font-black uppercase tracking-[0.6em] text-center mb-24 opacity-60 italic">Your daily guide to a better life</p>
          
          <div className="space-y-8">
            {HEALTH_TIPS.map((tip, i) => (
              <div key={i} className="bg-white/5 backdrop-blur-3xl p-10 rounded-[4rem] border border-white/10 hover:bg-white/10 transition-all group overflow-hidden relative">
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl"></div>
                <div className="flex items-center gap-8 relative z-10">
                   <div className="w-20 h-20 shrink-0 bg-emerald-600 rounded-[2.5rem] flex items-center justify-center text-4xl shadow-3xl shadow-emerald-950 group-hover:rotate-12 transition-transform duration-700">✨</div>
                   <div>
                      <h4 className="font-black text-white text-xl mb-3 tracking-tight">{language === 'bn' ? tip.titleBn : tip.title}</h4>
                      <p className="text-sm text-emerald-100/40 font-medium leading-relaxed">{language === 'bn' ? tip.descBn : tip.desc}</p>
                   </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Elite Request Modal */}
      {showRequest && (
        <div className="fixed inset-0 z-[150] bg-gray-950/95 backdrop-blur-3xl flex items-end justify-center p-6">
          <form onSubmit={handleSubmit} className="bg-white w-full max-w-md rounded-[5rem] p-12 space-y-8 animate-in slide-in-from-bottom duration-700 mb-4 border-t-8 border-emerald-600 shadow-3xl">
             <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-3xl font-black text-gray-900 tracking-tight">{t.requestMed}</h2>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.4em] mt-3">Health Concierge</p>
                </div>
                <button type="button" onClick={() => setShowRequest(false)} className="w-14 h-14 bg-slate-50 rounded-[1.75rem] flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.5" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
             </div>
             <div className="space-y-4">
                <input required placeholder="Your Name" className="w-full bg-slate-50 rounded-[2rem] px-8 py-6 text-sm font-bold border-2 border-transparent focus:border-emerald-500/20 outline-none transition-all shadow-inner" value={reqForm.name} onChange={e => setReqForm({...reqForm, name: e.target.value})} />
                <input required type="tel" placeholder="Mobile Number" className="w-full bg-slate-50 rounded-[2rem] px-8 py-6 text-sm font-bold border-2 border-transparent focus:border-emerald-500/20 outline-none transition-all shadow-inner" value={reqForm.phone} onChange={e => setReqForm({...reqForm, phone: e.target.value})} />
                <input required placeholder="Medicine Name" className="w-full bg-slate-50 rounded-[2rem] px-8 py-6 text-sm font-bold border-2 border-transparent focus:border-emerald-500/20 outline-none transition-all shadow-inner" value={reqForm.med} onChange={e => setReqForm({...reqForm, med: e.target.value})} />
                <textarea placeholder="Message..." className="w-full bg-slate-50 rounded-[2rem] px-8 py-6 text-sm font-bold border-2 border-transparent focus:border-emerald-500/20 outline-none transition-all h-32 resize-none shadow-inner" value={reqForm.msg} onChange={e => setReqForm({...reqForm, msg: e.target.value})}></textarea>
             </div>
             <button type="submit" className="w-full bg-emerald-600 text-white py-8 rounded-[2rem] font-black text-[12px] uppercase tracking-[0.5em] shadow-2xl active:scale-95 transition-all">
               {t.submit}
             </button>
          </form>
        </div>
      )}

      {/* Modern High-End Footer */}
      <footer className="bg-gray-950 text-white pt-32 pb-16 px-10 rounded-t-[6rem] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-[100px] -mr-48 -mt-48"></div>
        <div className="max-w-md mx-auto relative z-10">
          <div className="text-center mb-28">
            {/* New Premium Squircle Logo in Footer */}
            <div className="w-28 h-28 bg-emerald-600 rounded-[3rem] flex items-center justify-center text-white text-5xl font-black mx-auto mb-10 shadow-3xl animate-float relative overflow-hidden">
               <div className="shimmer-bar animate-shimmer opacity-30"></div>
               <span className="relative z-10">S</span>
            </div>
            <h3 className="text-4xl font-black mb-4 tracking-tighter">{language === 'bn' ? 'সাইফুল ফার্মাসি' : settings.name}</h3>
            <p className="text-[11px] font-black text-emerald-500 uppercase tracking-[0.6em] opacity-80">{settings.tagline}</p>
          </div>

          <div className="grid grid-cols-1 gap-5 mb-28">
            <FooterContactItem icon="📍" label="Address" value={settings.location} />
            <FooterContactItem icon="📞" label="Emergency" value={settings.phone} />
          </div>

          <div className="pt-12 border-t border-white/5 text-center">
            <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.6em] mb-6 tracking-widest">Digital Healthcare Solutions</p>
            <div className="flex justify-center gap-8">
               <span className="text-[9px] font-black text-emerald-500/30 uppercase tracking-[0.3em]">Verified Medical License</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

const PremiumServiceTile = ({ icon, title, desc, theme, onClick }: any) => {
  const themes: Record<string, string> = {
    emerald: 'bg-emerald-50/80 text-emerald-700 border-emerald-100/50',
    blue: 'bg-blue-50/80 text-blue-700 border-blue-100/50',
    pink: 'bg-pink-50/80 text-pink-700 border-pink-100/50',
    orange: 'bg-orange-50/80 text-orange-700 border-orange-100/50',
  };

  return (
    <div 
      onClick={onClick}
      className={`p-10 rounded-[3.5rem] border-2 transition-all hover:bg-white hover:shadow-2xl flex flex-col items-center text-center h-60 active:scale-95 cursor-pointer ${themes[theme] || 'bg-slate-50'}`}
    >
      <div className="w-16 h-16 rounded-[1.75rem] bg-white shadow-xl flex items-center justify-center text-4xl mb-6 hover:scale-110 transition-transform">
        {icon}
      </div>
      <p className="font-black text-[11px] uppercase tracking-[0.2em] leading-tight mb-2 text-gray-900">{title}</p>
      <p className="text-[8px] text-gray-400 font-black uppercase tracking-[0.25em]">{desc}</p>
    </div>
  );
};

const FooterContactItem = ({ icon, label, value }: any) => (
  <div className="bg-white/5 p-10 rounded-[4rem] border border-white/5 flex items-center gap-8 backdrop-blur-md hover:bg-white/10 transition-colors">
    <div className="w-16 h-16 bg-white/10 rounded-[2rem] flex items-center justify-center text-3xl shadow-inner">{icon}</div>
    <div>
      <p className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.4em] mb-2">{label}</p>
      <p className="text-[15px] font-bold opacity-80 leading-snug">{value}</p>
    </div>
  </div>
);

export default LandingPage;
