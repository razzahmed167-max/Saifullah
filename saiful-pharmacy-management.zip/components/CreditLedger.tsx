
import React, { useState } from 'react';
import { Customer } from '../types';

interface CreditLedgerProps {
  customers: Customer[];
  onAddCredit: (customerId: string, amount: number, desc: string, type: 'debt' | 'payment') => void;
}

const CreditLedger: React.FC<CreditLedgerProps> = ({ customers, onAddCredit }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentModal, setPaymentModal] = useState<{ open: boolean, customerId: string, customerName: string }>({ open: false, customerId: '', customerName: '' });
  const [paymentAmount, setPaymentAmount] = useState('');
  
  const debtCustomers = customers.filter(c => 
    (c.totalDebt > 0 || c.creditHistory.length > 0) &&
    (c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.phone.includes(searchTerm))
  ).sort((a, b) => b.totalDebt - a.totalDebt);

  const totalMarketDebt = customers.reduce((acc, curr) => acc + curr.totalDebt, 0);

  const isOverdue = (lastActivityDate: string) => {
    const today = new Date();
    const last = new Date(lastActivityDate);
    const diffTime = today.getTime() - last.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 14; // Consider overdue after 14 days of no payment
  };

  const sendWhatsApp = (customer: Customer, isOverdueAlert: boolean = false) => {
    const message = isOverdueAlert 
      ? `সালাম ${customer.name}, সাইফুল ফার্মাসি থেকে বলছি। আপনার বকেয়া টাকার পরিমাণ ৳${customer.totalDebt} অনেকদিন ধরে পরিশোধ করা হয়নি। অনুগ্রহ করে দ্রুত আমাদের সাথে যোগাযোগ করে বকেয়া পরিশোধ করার জন্য বিনীত অনুরোধ রইলো। ধন্যবাদ।`
      : `সালাম ${customer.name}, সাইফুল ফার্মাসি থেকে বলছি। আপনার বকেয়া টাকার পরিমাণ: ৳${customer.totalDebt}। অনুগ্রহ করে দ্রুত পরিশোধ করার অনুরোধ রইলো। ধন্যবাদ।`;
    
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/88${customer.phone}?text=${encoded}`, '_blank');
  };

  const overdueCustomers = customers.filter(c => {
    const lastEntry = c.creditHistory[c.creditHistory.length - 1];
    return c.totalDebt > 0 && lastEntry && isOverdue(lastEntry.date);
  });

  const handlePayment = () => {
    const amt = Number(paymentAmount);
    if (amt <= 0) return;
    onAddCredit(paymentModal.customerId, amt, 'বকেয়া পরিশোধ (নগদ)', 'payment');
    setPaymentAmount('');
    setPaymentModal({ open: false, customerId: '', customerName: '' });
    alert("Payment recorded successfully!");
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-black text-gray-800 tracking-tight">বাকির খাতা</h2>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">Credit Ledger Management</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">Total Market Due</p>
            <p className="text-2xl font-black text-red-600 leading-none">৳{totalMarketDebt.toLocaleString()}</p>
          </div>
        </div>
        
        <div className="relative">
          <input 
            type="text" 
            placeholder="গ্রাহকের নাম বা ফোন..."
            className="w-full bg-gray-50 border border-gray-100 rounded-2xl px-4 py-3 pl-10 focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg className="w-5 h-5 absolute left-3 top-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Automated Collection Assistant */}
        {overdueCustomers.length > 0 && (
          <div className="bg-red-600 p-6 rounded-[2.5rem] shadow-xl shadow-red-100 text-white animate-in zoom-in duration-500 mb-6">
            <div className="flex justify-between items-start">
               <div>
                  <p className="text-[10px] font-black uppercase tracking-widest opacity-70">Collection Assistant</p>
                  <h3 className="text-xl font-black mt-1">{overdueCustomers.length} Overdue Accounts</h3>
                  <p className="text-[11px] font-medium opacity-80 mt-1">Found debts older than 14 days without activity.</p>
               </div>
               <div className="bg-white/20 p-2 rounded-xl">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" /></svg>
               </div>
            </div>
            <button 
              onClick={() => overdueCustomers.forEach(c => sendWhatsApp(c, true))}
              className="w-full bg-white text-red-700 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest mt-6 shadow-lg active:scale-95 transition-all"
            >
              Send Overdue Alerts to All
            </button>
          </div>
        )}

        {debtCustomers.map(customer => {
          const lastEntry = customer.creditHistory[customer.creditHistory.length - 1];
          const overdue = customer.totalDebt > 0 && lastEntry && isOverdue(lastEntry.date);
          
          return (
            <div key={customer.id} className={`bg-white rounded-[2rem] border shadow-sm overflow-hidden group transition-all ${overdue ? 'border-red-200 ring-1 ring-red-100' : 'border-gray-50'}`}>
              <div className="p-6 flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-gray-800 text-lg tracking-tight">{customer.name}</h3>
                    {overdue && <span className="text-[8px] font-black bg-red-500 text-white px-2 py-0.5 rounded-full uppercase">Overdue</span>}
                  </div>
                  <p className="text-xs text-gray-400 font-bold">{customer.phone}</p>
                  <div className="mt-4 flex gap-2">
                    <button 
                      onClick={() => sendWhatsApp(customer, overdue)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-tighter border transition-colors ${overdue ? 'bg-red-50 text-red-700 border-red-100 hover:bg-red-100' : 'bg-green-50 text-green-700 border-green-100 hover:bg-green-100'}`}
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                      {overdue ? 'Send Alert' : 'WhatsApp'}
                    </button>
                    <button 
                      onClick={() => setPaymentModal({ open: true, customerId: customer.id, customerName: customer.name })}
                      className="flex-1 bg-emerald-600 text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-tighter shadow-lg shadow-emerald-50 active:scale-95 transition-all"
                    >
                      Record Payment
                    </button>
                  </div>
                </div>
                <div className="text-right ml-4">
                  <p className={`text-2xl font-black leading-tight ${overdue ? 'text-red-600' : 'text-gray-900'}`}>৳{customer.totalDebt}</p>
                  <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mt-1">Due Amount</p>
                </div>
              </div>
              
              {customer.creditHistory.length > 0 && (
                <div className="bg-gray-50/50 p-5 border-t border-gray-50">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Recent Transactions</p>
                  <div className="space-y-3">
                    {customer.creditHistory.slice(-3).reverse().map(entry => (
                      <div key={entry.id} className="flex justify-between items-center text-xs">
                        <div className="flex flex-col">
                          <span className="text-gray-800 font-bold tracking-tight">{entry.description}</span>
                          <span className="text-[9px] text-gray-400 font-medium">{entry.date}</span>
                        </div>
                        <span className={`font-black tracking-tighter text-sm ${entry.type === 'debt' ? 'text-red-500' : 'text-emerald-600'}`}>
                          {entry.type === 'debt' ? '+' : '-'} ৳{entry.amount}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {debtCustomers.length === 0 && (
          <div className="py-20 flex flex-col items-center justify-center text-gray-300 space-y-4">
             <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
             </div>
             <p className="text-sm font-bold uppercase tracking-widest">বাকির খাতা খালি</p>
          </div>
        )}
      </div>

      {/* Payment Record Modal */}
      {paymentModal.open && (
        <div className="fixed inset-0 z-[100] bg-gray-900/60 backdrop-blur-sm flex items-end justify-center">
          <div className="bg-white w-full max-w-md rounded-t-[2.5rem] p-8 animate-in slide-in-from-bottom duration-300">
             <div className="flex justify-between items-start mb-6">
                <div>
                   <h2 className="text-xl font-black text-gray-800 tracking-tight">Record Payment</h2>
                   <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{paymentModal.customerName}</p>
                </div>
                <button onClick={() => setPaymentModal({ open: false, customerId: '', customerName: '' })} className="p-2 bg-gray-100 rounded-full">
                   <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
             </div>
             <div className="space-y-6">
                <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2 px-1">Amount Received (৳)</label>
                   <input 
                      type="number" 
                      placeholder="e.g. 500" 
                      className="w-full bg-gray-50 border-none rounded-2xl px-6 py-4 text-2xl font-black text-emerald-600 outline-none focus:ring-2 focus:ring-emerald-500"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      autoFocus
                   />
                </div>
                <button 
                  onClick={handlePayment}
                  disabled={!paymentAmount || Number(paymentAmount) <= 0}
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-emerald-100 disabled:opacity-50 active:scale-95 transition-all"
                >
                  Confirm Repayment
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreditLedger;
