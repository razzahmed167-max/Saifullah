
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Medicine, SaleRecord, ServiceRecord } from '../types';

interface DashboardProps {
  medicines: Medicine[];
  sales: SaleRecord[];
  serviceRecords: ServiceRecord[];
}

const Dashboard: React.FC<DashboardProps> = ({ medicines, sales, serviceRecords }) => {
  const totalSalesRevenue = useMemo(() => sales.reduce((acc, curr) => acc + curr.totalAmount, 0), [sales]);
  const totalServiceCommission = useMemo(() => serviceRecords.reduce((acc, curr) => acc + curr.commission, 0), [serviceRecords]);
  const totalInflow = totalSalesRevenue + totalServiceCommission;

  const lowStockItems = medicines.filter(m => m.stock < 100);
  
  const chartData = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const today = new Date();
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(today.getDate() - i);
      const dayName = days[date.getDay()];
      const daySales = sales
        .filter(s => new Date(s.date).toDateString() === date.toDateString())
        .reduce((acc, curr) => acc + curr.totalAmount, 0);
      result.push({ name: dayName, sales: daySales });
    }
    return result;
  }, [sales]);

  return (
    <div className="space-y-6 pb-20">
      <header className="px-4 pt-6">
        <h1 className="text-2xl font-black text-gray-800 tracking-tight">Overview</h1>
        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Pharmacy & Services Admin</p>
      </header>

      <div className="px-4">
        <div className="bg-emerald-600 p-6 rounded-[2.5rem] shadow-xl shadow-emerald-100 text-white">
           <p className="text-[10px] opacity-70 uppercase font-black tracking-widest">Total Business Revenue</p>
           <p className="text-3xl font-black mt-1">৳{totalInflow.toLocaleString()}</p>
           <div className="mt-4 flex gap-4 pt-4 border-t border-white/20">
              <div>
                <p className="text-[9px] font-black uppercase opacity-60">Med Sales</p>
                <p className="text-sm font-bold">৳{totalSalesRevenue.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-[9px] font-black uppercase opacity-60">Commissions</p>
                <p className="text-sm font-bold">৳{totalServiceCommission.toLocaleString()}</p>
              </div>
           </div>
        </div>
      </div>

      <div className="px-4">
        <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm space-y-4">
           <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Digital Service Mix</h3>
           <div className="grid grid-cols-3 gap-3">
              <div className="bg-gray-50 p-3 rounded-2xl text-center">
                <p className="text-[8px] font-black text-gray-400 uppercase">bKash</p>
                <p className="text-xs font-black text-gray-800">৳{serviceRecords.filter(r => r.type === 'bKash').length}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-2xl text-center">
                <p className="text-[8px] font-black text-gray-400 uppercase">Nagad</p>
                <p className="text-xs font-black text-gray-800">৳{serviceRecords.filter(r => r.type === 'Nagad').length}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-2xl text-center">
                <p className="text-[8px] font-black text-gray-400 uppercase">Recharge</p>
                <p className="text-xs font-black text-gray-800">৳{serviceRecords.filter(r => r.type === 'Recharge').length}</p>
              </div>
           </div>
        </div>
      </div>

      <div className="px-4">
        <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f9fafb" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#d1d5db' }} />
              <YAxis hide />
              <Tooltip />
              <Bar dataKey="sales" radius={[8, 8, 8, 8]}>
                {chartData.map((e, i) => <Cell key={i} fill={i === 6 ? '#059669' : '#e5e7eb'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="px-4">
        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-3 px-1">Alerts</h3>
        {lowStockItems.slice(0, 3).map(item => (
          <div key={item.id} className="p-4 bg-white border border-red-50 rounded-2xl mb-2 flex justify-between items-center">
            <div>
              <p className="font-bold text-gray-900 text-sm">{item.name}</p>
              <p className="text-[10px] text-red-500 font-bold uppercase">Stock: {item.stock}</p>
            </div>
            <button className="bg-red-500 text-white px-3 py-1.5 rounded-xl text-[9px] font-black uppercase">Refill</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
