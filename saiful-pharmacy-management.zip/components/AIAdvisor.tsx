
import React, { useState, useEffect } from 'react';
import { getInventoryInsights, getHealthAdvice, batchGetMedicineDescriptions, getReorderSuggestions, getFinancialAdvice, ReorderSuggestion } from '../services/geminiService';
import { Medicine, SaleRecord, Expense, ServiceRecord, PurchaseRecord } from '../types';

interface AIAdvisorProps {
  medicines: Medicine[];
  sales: SaleRecord[];
  expenses: Expense[];
  services: ServiceRecord[];
  purchases: PurchaseRecord[];
  onUpdateMedicine: (id: string, updates: Partial<Medicine>) => void;
}

const AIAdvisor: React.FC<AIAdvisorProps> = ({ medicines, sales, expenses, services, purchases, onUpdateMedicine }) => {
  const [insights, setInsights] = useState<string>('');
  const [strategy, setStrategy] = useState<string>('');
  const [reorders, setReorders] = useState<ReorderSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [reorderLoading, setReorderLoading] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [chat, setChat] = useState<{role: 'ai' | 'user', text: string}[]>([]);
  
  const [enhancing, setEnhancing] = useState(false);
  const [enhancementProgress, setEnhancementProgress] = useState(0);

  const runAnalysis = async () => {
    setLoading(true);
    setReorderLoading(true);
    
    try {
      const [insightsRes, reordersRes, strategyRes] = await Promise.all([
        getInventoryInsights(medicines),
        getReorderSuggestions(medicines, sales),
        getFinancialAdvice(sales, expenses, services, medicines, purchases)
      ]);
      setInsights(insightsRes);
      setReorders(reordersRes);
      setStrategy(strategyRes || "");
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setLoading(false);
      setReorderLoading(false);
    }
  };

  useEffect(() => {
    runAnalysis();
  }, [medicines, sales]);

  const handleAsk = async () => {
    if (!userInput.trim()) return;
    const userText = userInput;
    setUserInput('');
    setChat(prev => [...prev, { role: 'user', text: userText }]);
    
    setLoading(true);
    const aiText = await getHealthAdvice(userText);
    setChat(prev => [...prev, { role: 'ai', text: aiText || 'Sorry, I am offline.' }]);
    setLoading(false);
  };

  const generateBulkOrderText = () => {
    if (reorders.length === 0) return;
    const header = `SAIFUL PHARMACY - SMART PROCUREMENT PLAN (${new Date().toLocaleDateString()})\n--------------------------------\n`;
    const body = reorders.map(r => `- ${r.name}: ${r.suggestedQuantity} units (Supplier: ${r.supplierRecommendation})\n  Negotiation: ${r.negotiationPoints}`).join('\n\n');
    const footer = `\n--------------------------------\nTotal Estimated Procurement Items: ${reorders.length}\nEst. Total Investment: ৳${reorders.reduce((a, b) => a + (b.estimatedCost || 0), 0).toLocaleString()}`;
    
    const fullText = header + body + footer;
    navigator.clipboard.writeText(fullText);
    alert('Smart Reorder Plan copied to clipboard!');
  };

  const handleEnhanceInventory = async () => {
    const medsToEnhance = medicines.filter(m => !m.description);
    if (medsToEnhance.length === 0) {
      alert("All medicines already have AI descriptions!");
      return;
    }

    setEnhancing(true);
    setEnhancementProgress(0);

    const chunkSize = 8;
    const totalToEnhance = medsToEnhance.length;
    let processedCount = 0;

    try {
      for (let i = 0; i < totalToEnhance; i += chunkSize) {
        const chunk = medsToEnhance.slice(i, i + chunkSize);
        const descriptionsMap = await batchGetMedicineDescriptions(chunk);
        
        Object.entries(descriptionsMap).forEach(([id, description]) => {
          onUpdateMedicine(id, { description });
        });

        processedCount += chunk.length;
        setEnhancementProgress(Math.floor((processedCount / totalToEnhance) * 100));
      }
      alert(`Success! ${totalToEnhance} descriptions generated.`);
    } catch (error) {
      console.error("Enhancement failed:", error);
      alert("Something went wrong during enhancement.");
    } finally {
      setEnhancing(false);
      setEnhancementProgress(0);
    }
  };

  const medsWithoutDesc = medicines.filter(m => !m.description).length;

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] pb-16">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center sticky top-0 z-30">
        <h2 className="text-xl font-black flex items-center gap-2 text-gray-800">
          <span className="bg-emerald-100 text-emerald-600 p-2 rounded-xl">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </span>
          AI Advisor
        </h2>
        <button 
          onClick={runAnalysis}
          disabled={reorderLoading}
          className="bg-emerald-600 text-white p-2.5 rounded-xl shadow-lg active:scale-95 disabled:opacity-50"
        >
          <svg className={`w-5 h-5 ${reorderLoading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-8 no-scrollbar bg-gray-50/50">
        
        {/* Growth Strategy & Promotions Card */}
        <section className="animate-in fade-in slide-in-from-bottom duration-700">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-900 p-8 rounded-[3rem] shadow-2xl relative overflow-hidden text-white">
             <div className="absolute top-0 right-0 p-6 opacity-10">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 20 20"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" /></svg>
             </div>
             <div className="relative z-10">
                <span className="bg-white/20 text-[10px] font-black uppercase tracking-[0.4em] px-3 py-1 rounded-full mb-4 inline-block">Growth Strategy</span>
                <h3 className="text-2xl font-black mb-6 tracking-tight">Business Intelligence Advice</h3>
                
                {loading && !strategy ? (
                  <div className="space-y-3 animate-pulse">
                    <div className="h-4 bg-white/10 rounded w-full"></div>
                    <div className="h-4 bg-white/10 rounded w-5/6"></div>
                    <div className="h-4 bg-white/10 rounded w-4/6"></div>
                  </div>
                ) : (
                  <div className="text-sm leading-relaxed whitespace-pre-wrap font-medium opacity-90 prose-invert">
                    {strategy || "Analyzing category performance and margins..."}
                  </div>
                )}
             </div>
          </div>
        </section>

        {/* Catalog Enhancement Feature */}
        <section className="animate-in fade-in slide-in-from-top duration-500">
          <div className="bg-white p-8 rounded-[2.5rem] border border-emerald-100 shadow-xl shadow-emerald-50 flex flex-col gap-6 relative overflow-hidden">
             <div className="absolute -top-4 -right-4 w-24 h-24 bg-emerald-50 rounded-full opacity-50"></div>
             <div className="relative z-10">
                <h3 className="text-lg font-black text-gray-800 leading-tight">Catalog Intelligence</h3>
                <p className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mt-1">Smart Description Engine</p>
                <p className="text-xs text-gray-500 mt-3 leading-relaxed">
                  Generate professional AI-powered medical descriptions for your inventory to help customers understand usage and precautions.
                </p>
             </div>
             
             {enhancing ? (
                <div className="space-y-4">
                   <div className="flex justify-between items-end">
                      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest animate-pulse">Analyzing Pharmacy Catalog...</span>
                      <span className="text-xl font-black text-emerald-600">{enhancementProgress}%</span>
                   </div>
                   <div className="w-full h-3 bg-emerald-50 rounded-full overflow-hidden border border-emerald-100 p-0.5">
                      <div className="h-full bg-emerald-600 rounded-full transition-all duration-500 ease-out" style={{ width: `${enhancementProgress}%` }}></div>
                   </div>
                </div>
             ) : (
                <div className="flex flex-col gap-3">
                   <button 
                      onClick={handleEnhanceInventory}
                      className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-100 active:scale-95 transition-all flex items-center justify-center gap-2 group"
                   >
                      <svg className="w-5 h-5 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.628.285a2 2 0 01-1.586 0l-.628-.285a6 6 0 00-3.86-.517l-2.387.477a2 2 0 00-1.022.547l-1.159 1.159a2 2 0 00-.586 1.414V20a2 2 0 002 2h12a2 2 0 002 2h12a2 2 0 002-2v-3.414a2 2 0 00-.586-1.414l-1.159-1.159z" /></svg>
                      {medsWithoutDesc === 0 ? "Re-Scan for Updates" : `Enhance ${medsWithoutDesc} Items`}
                   </button>
                </div>
             )}
          </div>
        </section>

        {/* AI Performance Insight */}
        <section>
          <div className="flex justify-between items-center mb-3 px-1">
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Inventory Health</h3>
            <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md uppercase">Stock Analysis</span>
          </div>
          <div className="bg-gray-950 p-6 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
            {loading && !insights ? (
              <div className="animate-pulse space-y-2">
                <div className="h-4 bg-white/10 rounded w-3/4"></div>
                <div className="h-4 bg-white/10 rounded w-1/2"></div>
              </div>
            ) : (
              <p className="text-sm leading-relaxed whitespace-pre-wrap relative z-10 font-medium">
                {insights || "Analyzing stock health..."}
              </p>
            )}
          </div>
        </section>

        {/* Reorder Suggestions */}
        {reorders.length > 0 && (
           <section>
              <div className="flex justify-between items-center mb-4 px-1">
                 <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Smart Procurement</h3>
                 <button onClick={generateBulkOrderText} className="text-[9px] font-black uppercase text-emerald-600 underline">Copy Plan</button>
              </div>
              <div className="space-y-6">
                 {reorders.map((r, i) => (
                    <div key={i} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm relative group overflow-hidden">
                       <div className={`absolute top-0 right-0 px-3 py-1 rounded-bl-xl text-[8px] font-black uppercase ${r.priority === 'High' ? 'bg-red-500 text-white' : 'bg-orange-500 text-white'}`}>{r.priority}</div>
                       
                       <div className="flex justify-between items-start mb-3">
                          <h4 className="font-black text-gray-800 text-sm">{r.name}</h4>
                          <span className="bg-emerald-50 text-emerald-700 text-[8px] px-2 py-0.5 rounded-full font-black uppercase">{r.supplierRecommendation}</span>
                       </div>

                       <div className="bg-gray-50 p-4 rounded-2xl mb-4 border border-gray-100/50">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-1">Reason</p>
                          <p className="text-[11px] text-gray-600 italic">"{r.reason}"</p>
                       </div>

                       <div className="grid grid-cols-1 gap-3 mb-4">
                          <div className="flex items-center gap-2 bg-blue-50/50 p-3 rounded-xl border border-blue-100/50">
                             <span className="text-lg">📈</span>
                             <div>
                                <p className="text-[8px] text-blue-600 font-black uppercase tracking-widest">Negotiation Strategy</p>
                                <p className="text-[10px] text-blue-800 font-bold leading-tight">{r.negotiationPoints}</p>
                             </div>
                          </div>
                          
                          {r.bulkDiscountPotential && (
                             <div className="flex items-center gap-2 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/50">
                                <span className="text-lg">🎁</span>
                                <div>
                                   <p className="text-[8px] text-emerald-600 font-black uppercase tracking-widest">Bulk Opportunity</p>
                                   <p className="text-[10px] text-emerald-800 font-bold leading-tight">{r.bulkDiscountPotential}</p>
                                </div>
                             </div>
                          )}
                       </div>

                       <div className="flex justify-between items-end border-t border-gray-50 pt-3">
                          <div>
                             <p className="text-[8px] text-gray-400 font-black uppercase">Order Target</p>
                             <p className="text-xs font-black text-emerald-600">+{r.suggestedQuantity} Units</p>
                          </div>
                          <div className="text-right">
                             <p className="text-[8px] text-gray-400 font-black uppercase">Est. Cost</p>
                             <p className="text-xs font-black text-gray-700">৳{(r.estimatedCost || 0).toLocaleString()}</p>
                          </div>
                       </div>
                    </div>
                 ))}
              </div>
           </section>
        )}

        {/* Chat Assistant */}
        <section className="space-y-4">
          <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest px-1">Medical Assistant Chat</h3>
          <div className="space-y-3">
            {chat.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-5 py-4 rounded-3xl text-sm ${msg.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-white border border-gray-100 text-gray-700 rounded-tl-none'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Chat Input */}
      <div className="p-4 bg-white border-t border-gray-100 sticky bottom-0 z-20">
        <div className="flex gap-2">
          <input 
            type="text" 
            placeholder="Ask AI about dosage or interactions..."
            className="flex-1 bg-gray-50 border-none rounded-[1.5rem] px-5 py-4 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAsk()}
          />
          <button 
            onClick={handleAsk}
            disabled={loading}
            className="bg-emerald-600 text-white p-4 rounded-[1.5rem] shadow-xl disabled:opacity-50 active:scale-95 transition-all"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIAdvisor;
