
import React, { useState } from 'react';
import { PharmacySettings } from '../types';

interface SettingsProps {
  language: string;
  onLanguageToggle: () => void;
  settings: PharmacySettings;
  onUpdateSettings: (s: PharmacySettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ language, onLanguageToggle, settings, onUpdateSettings }) => {
  const [editSettings, setEditSettings] = useState<PharmacySettings>(settings);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdateSettings(editSettings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-10">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">System Settings</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Configure Business Rules</p>
      </header>

      <div className="p-6 space-y-8">
         <section>
            <div className="flex justify-between items-center mb-4">
               <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Pharmacy Profile</h3>
               {isSaved && <span className="text-[10px] font-black text-emerald-600 uppercase">Changes Saved!</span>}
            </div>
            <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 space-y-5 shadow-sm">
               <div>
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1.5 ml-1">Shop Name</label>
                  <input 
                    value={editSettings.name} 
                    onChange={e => setEditSettings({...editSettings, name: e.target.value})}
                    className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-emerald-500" 
                  />
               </div>
               <div>
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1.5 ml-1">Location</label>
                  <input 
                    value={editSettings.location} 
                    onChange={e => setEditSettings({...editSettings, location: e.target.value})}
                    className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-emerald-500" 
                  />
               </div>
               <div>
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1.5 ml-1">Contact Phone</label>
                  <input 
                    value={editSettings.phone} 
                    onChange={e => setEditSettings({...editSettings, phone: e.target.value})}
                    className="w-full bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-emerald-500" 
                  />
               </div>
               <button 
                 onClick={handleSave}
                 className="w-full bg-emerald-600 text-white py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-emerald-50 active:scale-95 transition-all"
               >
                 Update Profile
               </button>
            </div>
         </section>

         <section>
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Localization</h3>
            <button onClick={onLanguageToggle} className="w-full bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm flex justify-between items-center group active:scale-95 transition-all">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg">🌐</div>
                  <div className="text-left">
                     <p className="text-sm font-black text-gray-800">Current Language</p>
                     <p className="text-[10px] text-gray-400 font-bold uppercase">{language === 'en' ? 'English' : 'বাংলা'}</p>
                  </div>
               </div>
               <div className="bg-gray-50 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">Switch</div>
            </button>
         </section>

         <section>
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Security</h3>
            <div className="bg-red-50 p-6 rounded-[2.5rem] border border-red-100 flex items-center justify-between">
               <div>
                  <p className="text-sm font-black text-red-600">Admin Session</p>
                  <p className="text-[10px] text-red-400 font-bold uppercase">Encrypted Connection</p>
               </div>
               <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-red-500">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
               </div>
            </div>
         </section>

         <div className="pt-4 text-center">
            <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Saiful Enterprise v3.2-PRO</p>
         </div>
      </div>
    </div>
  );
};

export default Settings;
