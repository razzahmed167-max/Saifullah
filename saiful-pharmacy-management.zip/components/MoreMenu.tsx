
import React from 'react';
import { AppTab } from '../types';

interface MoreMenuProps {
  onSelectTab: (tab: AppTab) => void;
}

const MoreMenu: React.FC<MoreMenuProps> = ({ onSelectTab }) => {
  const menuItems = [
    { id: AppTab.INVENTORY, label: 'Inventory', icon: '📦', color: 'bg-blue-50 text-blue-600' },
    { id: AppTab.CUSTOMERS, label: 'Customers', icon: '👥', color: 'bg-emerald-50 text-emerald-600' },
    { id: AppTab.PURCHASES, label: 'Stock In', icon: '📥', color: 'bg-indigo-50 text-indigo-600' },
    { id: AppTab.LEDGER, label: 'Baki Khata', icon: '📒', color: 'bg-red-50 text-red-600' },
    { id: AppTab.REPORTS, label: 'Financials', icon: '📊', color: 'bg-purple-50 text-purple-600' },
    { id: AppTab.EXPENSES, label: 'Expenses', icon: '💸', color: 'bg-pink-50 text-pink-600' },
    { id: AppTab.STAFF, label: 'Staffs', icon: '👨‍⚕️', color: 'bg-orange-50 text-orange-600' },
    { id: AppTab.SUPPLIERS, label: 'Suppliers', icon: '🏭', color: 'bg-cyan-50 text-cyan-600' },
    { id: AppTab.SERVICES, label: 'Services', icon: '📱', color: 'bg-teal-50 text-teal-600' },
    { id: AppTab.REQUESTS, label: 'Requests', icon: '📩', color: 'bg-amber-50 text-amber-600' },
    { id: AppTab.RETURNS, label: 'Returns', icon: '🔄', color: 'bg-rose-50 text-rose-600' },
    { id: AppTab.HISTORY, label: 'History', icon: '🕒', color: 'bg-gray-100 text-gray-600' },
    { id: AppTab.AI_ADVISOR, label: 'AI Advisor', icon: '✨', color: 'bg-yellow-50 text-yellow-600' },
    { id: AppTab.SETTINGS, label: 'Settings', icon: '⚙️', color: 'bg-slate-50 text-slate-600' },
  ];

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Enterprise Suite</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Management Control Center</p>
      </header>

      <div className="p-4 grid grid-cols-3 gap-3">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className="flex flex-col items-center justify-center p-4 bg-white rounded-3xl border border-gray-50 shadow-sm transition-all active:scale-95 group h-32"
          >
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl mb-2 shadow-inner ${item.color}`}>
              {item.icon}
            </div>
            <span className="text-[9px] font-black text-gray-700 uppercase tracking-tight text-center leading-tight">{item.label}</span>
          </button>
        ))}
      </div>
      
      <div className="px-4 mt-2">
         <div className="bg-gray-900 rounded-[2rem] p-5 text-white flex items-center justify-between shadow-xl">
            <div>
               <p className="text-[9px] font-black uppercase tracking-widest opacity-50">App Status</p>
               <p className="text-xs font-bold">Saiful Enterprise v3.0-PRO</p>
            </div>
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center animate-pulse">
               <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default MoreMenu;
