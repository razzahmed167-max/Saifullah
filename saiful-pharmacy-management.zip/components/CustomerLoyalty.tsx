
import React, { useState } from 'react';
import { Customer } from '../types';

interface CustomerLoyaltyProps {
  customers: Customer[];
  onAddCustomer: (customer: Omit<Customer, 'id' | 'points' | 'lifetimeSpend' | 'joinDate'>) => void;
  onUpdateCustomer: (id: string, updates: Partial<Pick<Customer, 'name' | 'phone'>>) => void;
}

const CustomerLoyalty: React.FC<CustomerLoyaltyProps> = ({ customers, onAddCustomer, onUpdateCustomer }) => {
  const [search, setSearch] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  
  // State for editing
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.phone.includes(search)
  );

  const handleAdd = () => {
    if (!newName || !newPhone) return;
    onAddCustomer({ name: newName, phone: newPhone });
    setNewName('');
    setNewPhone('');
    setIsAdding(false);
  };

  const startEditing = (customer: Customer) => {
    setEditingId(customer.id);
    setEditName(customer.name);
    setEditPhone(customer.phone);
  };

  const handleUpdate = (id: string) => {
    if (!editName || !editPhone) return;
    onUpdateCustomer(id, { name: editName, phone: editPhone });
    setEditingId(null);
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center sticky top-0 z-10">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Customers</h2>
          <p className="text-xs text-gray-500">Loyalty & Rewards Program</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-lg shadow-emerald-100 flex items-center gap-2"
        >
          {isAdding ? 'Cancel' : (
            <><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg> Add New</>
          )}
        </button>
      </header>

      {isAdding && (
        <div className="p-4 bg-white border-b border-gray-100 animate-in slide-in-from-top duration-300">
          <div className="space-y-3">
            <input 
              type="text" 
              placeholder="Customer Full Name" 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
            />
            <input 
              type="tel" 
              placeholder="Phone Number" 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
            />
            <button 
              onClick={handleAdd}
              className="w-full bg-emerald-600 text-white font-bold py-3 rounded-xl shadow-lg active:scale-95 transition-transform"
            >
              Register Customer
            </button>
          </div>
        </div>
      )}

      <div className="p-4">
        <div className="relative mb-6">
          <input 
            type="text" 
            placeholder="Search by name or phone..."
            className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 pl-10 focus:ring-2 focus:ring-emerald-500 outline-none shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <svg className="w-5 h-5 absolute left-3 top-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>

        <div className="space-y-4">
          {filteredCustomers.map(customer => {
            const isEditing = editingId === customer.id;
            return (
              <div key={customer.id} className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm relative overflow-hidden group transition-all">
                <div className="absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 bg-emerald-50 rounded-full group-hover:bg-emerald-100 transition-colors"></div>
                
                <div className="relative flex justify-between items-start">
                  <div className="space-y-2 flex-1 mr-4">
                    {isEditing ? (
                      <div className="space-y-2 animate-in fade-in duration-200">
                        <input 
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full bg-gray-50 border border-emerald-200 rounded-lg px-3 py-1.5 text-sm font-bold focus:ring-1 focus:ring-emerald-500 outline-none"
                        />
                        <input 
                          type="tel"
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          className="w-full bg-gray-50 border border-emerald-200 rounded-lg px-3 py-1.5 text-sm focus:ring-1 focus:ring-emerald-500 outline-none"
                        />
                        <div className="flex gap-2 pt-1">
                          <button 
                            onClick={() => handleUpdate(customer.id)}
                            className="bg-emerald-600 text-white px-3 py-1 rounded-lg text-xs font-bold"
                          >
                            Save
                          </button>
                          <button 
                            onClick={() => setEditingId(null)}
                            className="bg-gray-100 text-gray-600 px-3 py-1 rounded-lg text-xs font-bold"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-gray-800">{customer.name}</h3>
                          <button 
                            onClick={() => startEditing(customer)}
                            className="text-gray-400 hover:text-emerald-600 p-1 rounded-md hover:bg-emerald-50 transition-colors"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                          </button>
                        </div>
                        <p className="text-sm text-gray-500 flex items-center gap-1">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                          {customer.phone}
                        </p>
                        <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mt-2">Member Since: {customer.joinDate}</p>
                      </>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <div className="bg-emerald-600 text-white px-3 py-2 rounded-2xl inline-block shadow-md">
                      <p className="text-[10px] font-bold uppercase tracking-tighter opacity-80">Balance</p>
                      <p className="text-xl font-black">{customer.points} <span className="text-xs">pts</span></p>
                    </div>
                    <p className="text-[10px] text-gray-400 font-bold mt-2">Spent: ৳{customer.lifetimeSpend.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            );
          })}
          {filteredCustomers.length === 0 && (
            <div className="py-20 text-center text-gray-400 italic">No customers found</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomerLoyalty;
