
import React, { useMemo, useState } from 'react';
import { SaleRecord, Expense, ServiceRecord, Medicine, PurchaseRecord } from '../types';
import { getFinancialAdvice } from '../services/geminiService';

interface FinancialReportsProps {
  sales: SaleRecord[];
  expenses: Expense[];
  serviceRecords: ServiceRecord[];
  // Added missing types for AI analysis
  medicines: Medicine[];
  purchases: PurchaseRecord[];
}

const FinancialReports: React.FC<FinancialReportsProps> = ({ sales, expenses, serviceRecords, medicines, purchases }) => {
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  const stats = useMemo(() => {
    const totalSales = sales.filter(s => s.status !== 'returned').reduce((acc, curr) => acc + curr.totalAmount, 0);
    const totalServiceCom = serviceRecords.reduce((acc, curr) => acc + curr.commission, 0);
    const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
    const netProfit = (totalSales + totalServiceCom) - totalExpenses;

    return { totalSales, totalServiceCom, totalExpenses, netProfit };
  }, [sales, expenses, serviceRecords]);

  // Fix: Added missing medicines and purchases arguments to getFinancialAdvice
  const handleFetchAdvice = async () => {
    setLoadingAi(true);
    const advice = await getFinancialAdvice(sales, expenses, serviceRecords, medicines, purchases);
    setAiAdvice(advice || "Analysis failed.");
    setLoadingAi(false);
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Financial Reports</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Profit & Loss Summary</p>
      </header>

      <div className="p-4 space-y-6">
        {/* Profit Card */}
        <div className={`p-8 rounded-[2.5rem] text-white shadow-xl ${stats.netProfit >= 0 ? 'bg-emerald-600 shadow-emerald-100' : 'bg-red-600 shadow-red-100'}`}>
           <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Net Profit (Current Period)</p>
           <p className="text-4xl font-black mt-2">৳{stats.netProfit.toLocaleString()}</p>
           <div className="flex items-center gap-2 mt-2">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
              <p className="text-[10px] font-bold uppercase opacity-80">Real-time update</p>
           </div>
        </div>

        {/* AI Financial Health Advice */}
        <div className="bg-white border border-gray-100 p-6 rounded-[2.5rem] shadow-sm relative overflow-hidden group">
           <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <svg className="w-12 h-12 text-emerald-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
           </div>
           <h3 className="text-xs font-black text-emerald-600 uppercase tracking-widest mb-4 flex items-center gap-2">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              AI Business Auditor
           </h3>
           
           {aiAdvice ? (
             <div className="text-xs text-gray-600 leading-relaxed italic animate-in fade-in duration-500">
               {aiAdvice}
               <button onClick={handleFetchAdvice} className="block mt-4 text-[9px] font-black text-emerald-600 uppercase tracking-widest underline">Refresh Analysis</button>
             </div>
           ) : (
             <button 
               onClick={handleFetchAdvice}
               disabled={loadingAi}
               className="w-full bg-emerald-50 text-emerald-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 border border-emerald-100 active:scale-95 transition-all"
             >
               {loadingAi ? (
                 <><div className="w-3 h-3 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin"></div> Running Audit...</>
               ) : "Generate AI Health Check"}
             </button>
           )}
        </div>

        {/* Detailed Breakdown */}
        <div className="grid grid-cols-1 gap-4">
           <ReportCard title="Revenue from Sales" amount={stats.totalSales} color="text-blue-600" bg="bg-blue-50" />
           <ReportCard title="Service Commissions" amount={stats.totalServiceCom} color="text-teal-600" bg="bg-teal-50" />
           <ReportCard title="Total Operating Expenses" amount={stats.totalExpenses} color="text-pink-600" bg="bg-pink-50" negative />
        </div>

        {/* Cash Flow Insights */}
        <div className="bg-white border border-gray-100 p-6 rounded-[2.5rem] shadow-sm">
           <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Operational Efficiency</h3>
           <div className="space-y-4">
              <ProgressBar label="Profit Margin" progress={Math.min(100, Math.floor((stats.netProfit / (stats.totalSales || 1)) * 100))} color="bg-blue-500" />
              <ProgressBar label="Expense Ratio" progress={Math.min(100, Math.floor((stats.totalExpenses / (stats.totalSales || 1)) * 100))} color="bg-pink-500" />
              <ProgressBar label="Digital Service Yield" progress={85} color="bg-teal-500" />
           </div>
        </div>
      </div>
    </div>
  );
};

const ReportCard = ({ title, amount, color, bg, negative }: any) => (
  <div className="bg-white p-5 rounded-[2rem] border border-gray-50 shadow-sm flex justify-between items-center">
    <div>
      <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{title}</p>
      <p className={`text-xl font-black mt-0.5 ${color}`}>{negative ? '-' : ''}৳{amount.toLocaleString()}</p>
    </div>
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bg}`}>
      <svg className={`w-5 h-5 ${color}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
    </div>
  </div>
);

const ProgressBar = ({ label, progress, color }: any) => (
  <div className="space-y-1.5">
    <div className="flex justify-between text-[10px] font-black uppercase tracking-tight">
       <span className="text-gray-500">{label}</span>
       <span className="text-gray-800">{progress}%</span>
    </div>
    <div className="w-full h-1.5 bg-gray-50 rounded-full overflow-hidden">
       <div className={`h-full ${color} transition-all duration-300`} style={{ width: `${progress}%` }}></div>
    </div>
  </div>
);

export default FinancialReports;
