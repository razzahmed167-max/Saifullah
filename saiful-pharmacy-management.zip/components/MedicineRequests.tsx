
import React from 'react';
import { MedicineRequest } from '../types';

interface MedicineRequestsProps {
  requests: MedicineRequest[];
  onUpdateStatus: (id: string, status: 'completed' | 'cancelled') => void;
}

const MedicineRequests: React.FC<MedicineRequestsProps> = ({ requests, onUpdateStatus }) => {
  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Customer Requests</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Pending Inquiries from Public Site</p>
      </header>

      <div className="p-4 space-y-4">
        {requests.map(req => (
          <div key={req.id} className={`bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm transition-opacity ${req.status !== 'pending' ? 'opacity-50' : ''}`}>
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-black text-gray-800 text-sm">{req.medicineName}</h3>
                <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest">{req.status}</p>
              </div>
              <p className="text-[10px] text-gray-300 font-bold">{req.date.split('T')[0]}</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-2xl mb-4">
              <p className="text-xs text-gray-600 leading-relaxed italic">"{req.message || 'No message provided'}"</p>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <p className="text-[9px] text-gray-400 font-bold uppercase">Requested By</p>
                <p className="text-xs font-black text-gray-700">{req.customerName} • {req.phone}</p>
              </div>
              {req.status === 'pending' && (
                <div className="flex gap-2">
                   <button onClick={() => onUpdateStatus(req.id, 'completed')} className="bg-emerald-600 text-white p-2 rounded-xl">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                   </button>
                   <button onClick={() => onUpdateStatus(req.id, 'cancelled')} className="bg-red-50 text-red-500 p-2 rounded-xl">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                   </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {requests.length === 0 && <p className="text-center text-xs text-gray-400 italic py-20">No requests yet.</p>}
      </div>
    </div>
  );
};

export default MedicineRequests;
