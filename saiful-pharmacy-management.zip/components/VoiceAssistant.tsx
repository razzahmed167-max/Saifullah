
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, Type, FunctionDeclaration } from '@google/genai';
import { Customer } from '../types';

interface VoiceAssistantProps {
  customers: Customer[];
  onVoiceCommandResult: (type: 'debt' | 'reminder', customerName: string, amount?: number, items?: string) => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ customers, onVoiceCommandResult }) => {
  const [isActive, setIsActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcription, setTranscription] = useState('');
  
  // Audio context and nodes
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const recordDebtFunction: FunctionDeclaration = {
    name: 'recordDebt',
    parameters: {
      type: Type.OBJECT,
      description: 'Record a customer debt in the ledger.',
      properties: {
        customerName: { type: Type.STRING, description: 'Name of the customer' },
        amount: { type: Type.NUMBER, description: 'Amount of debt in Taka' },
        description: { type: Type.STRING, description: 'Details like medicine names' }
      },
      required: ['customerName', 'amount']
    }
  };

  const sendReminderFunction: FunctionDeclaration = {
    name: 'sendReminder',
    parameters: {
      type: Type.OBJECT,
      description: 'Send a payment reminder via WhatsApp',
      properties: {
        customerName: { type: Type.STRING, description: 'Name of the customer to remind' }
      },
      required: ['customerName']
    }
  };

  const startListening = async () => {
    try {
      setIsActive(true);
      setTranscription("শুশছি... বলুন");
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `You are Saiful Pharmacy Assistant. Listen to the user's voice command in Bengali. 
      Identify if they want to record a debt (e.g., 'Rohim 100 taka baki') or send a WhatsApp reminder.
      Known Customers: ${customers.map(c => c.name).join(', ')}.
      
      User said: [VOICE INPUT]`;

      // Simulating voice processing with a prompt for now 
      // as standard Web Speech API is more reliable for simple Bengali commands 
      // compared to full PCM streaming in this environment without complex buffer handling.
      
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.lang = 'bn-BD';
      recognition.onresult = async (event: any) => {
        const text = event.results[0][0].transcript;
        setTranscription(text);
        setIsProcessing(true);

        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Analyze this pharmacy command: "${text}". 
          Extract details for function calling. 
          Customers available: ${customers.map(c => c.name).join(', ')}.`,
          config: {
            tools: [{ functionDeclarations: [recordDebtFunction, sendReminderFunction] }]
          }
        });

        if (response.functionCalls) {
          for (const fc of response.functionCalls) {
            if (fc.name === 'recordDebt') {
              const { customerName, amount, description } = fc.args as any;
              onVoiceCommandResult('debt', customerName, amount, description);
            } else if (fc.name === 'sendReminder') {
              const { customerName } = fc.args as any;
              onVoiceCommandResult('reminder', customerName);
            }
          }
        }
        setIsProcessing(false);
        setIsActive(false);
      };
      recognition.start();

    } catch (err) {
      console.error(err);
      setIsActive(false);
    }
  };

  return (
    <div className="fixed bottom-24 right-4 z-50">
      <div className={`absolute bottom-full right-0 mb-4 transition-all duration-300 transform ${isActive ? 'scale-100 opacity-100' : 'scale-90 opacity-0 pointer-events-none'}`}>
        <div className="bg-white p-4 rounded-3xl shadow-2xl border border-emerald-100 min-w-[200px]">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex gap-1">
              <span className="w-1 h-4 bg-emerald-500 rounded-full animate-pulse"></span>
              <span className="w-1 h-6 bg-emerald-500 rounded-full animate-pulse delay-75"></span>
              <span className="w-1 h-3 bg-emerald-500 rounded-full animate-pulse delay-150"></span>
            </div>
            <p className="text-xs font-bold text-emerald-600">Smart Voice Assistant</p>
          </div>
          <p className="text-sm text-gray-700 italic">"{transcription}"</p>
          {isProcessing && (
            <p className="text-[10px] text-emerald-500 mt-2 font-black animate-pulse uppercase">Processing Ledger...</p>
          )}
        </div>
      </div>

      <button 
        onClick={startListening}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-xl transition-all active:scale-90 ${isActive ? 'bg-red-500 animate-pulse' : 'bg-emerald-600 hover:bg-emerald-700'}`}
      >
        {isActive ? (
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" /></svg>
        ) : (
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
        )}
      </button>
    </div>
  );
};

export default VoiceAssistant;
