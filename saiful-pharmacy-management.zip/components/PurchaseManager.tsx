
import React, { useState } from 'react';
import { Medicine, Supplier, PurchaseRecord } from '../types';

interface PurchaseManagerProps {
  medicines: Medicine[];
  suppliers: Supplier[];
  purchases: PurchaseRecord[];
  onAddPurchase: (pur: Omit<PurchaseRecord, 'id' | 'date'>) => void;
}

const PurchaseManager: React.FC<PurchaseManagerProps> = ({ medicines, suppliers, purchases, onAddPurchase }) => {
  const [medId, setMedId] = useState('');
  const [supId, setSupId] = useState('');
  const [qty, setQty] = useState('');
  const [cost, setCost] = useState('');
  const [dueDate, setDueDate] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medId || !supId || !qty || !cost || !dueDate) {
      alert('Please fill in all fields including the due date.');
      return;
    }
    const medName = medicines.find(m => m.id === medId)?.name || 'Unknown';
    onAddPurchase({ 
      medicineId: medId, 
      medicineName: medName, 
      supplierId: supId, 
      quantity: Number(qty), 
      costPrice: Number(cost),
      dueDate: dueDate
    });
    setQty('');
    setCost('');
    setDueDate('');
    alert('Purchase recorded and stock updated!');
  };

  const sendReminder = (purchase: PurchaseRecord) => {
    const supplier = suppliers.find(s => s.id === purchase.supplierId);
    if (!supplier) {
      alert("Supplier data not found.");
      return;
    }

    const message = `সালাম ${supplier.contactPerson} (${supplier.name}), সাইফুল ফার্মাসি থেকে বলছি। আমাদের ইনভয়েস #${purchase.id.slice(-4)} (${purchase.medicineName}) এর পেমেন্ট ডিউ ডেট ছিল ${new Date(purchase.dueDate).toLocaleDateString()}। আমরা শীঘ্রই পেমেন্ট পরিশোধ করছি। ধন্যবাদ।`;
    
    // Using WhatsApp as a modern business SMS alternative in the region
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/88${supplier.phone}?text=${encoded}`, '_blank');
  };

  const isNearDue = (dateStr: string) => {
    const today = new Date();
    const due = new Date(dateStr);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 3; // Within 3 days
  };

  const isOverdue = (dateStr: string) => {
    const today = new Date();
    const due = new Date(dateStr);
    return due < today;
  };

  const upcomingPayments = purchases.filter(p => isNearDue(p.dueDate) || isOverdue(p.dueDate));

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-10">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Stock Purchase</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Record Inward Inventory</p>
      </header>

      <div className="p-4">
        {/* Statistics & Automated Alerts */}
        <div className="mb-8 grid grid-cols-1 gap-4">
           {upcomingPayments.length > 0 && (
             <div className="bg-amber-600 p-6 rounded-[2.5rem] shadow-xl shadow-amber-100 text-white animate-in slide-in-from-top-4 duration-500">
                <div className="flex justify-between items-start">
                   <div>
                      <p className="text-[10px] font-black uppercase tracking-widest opacity-70">Automated Alert</p>
                      <h3 className="text-xl font-black mt-1">{upcomingPayments.length} Payments Due Soon</h3>
                      <p className="text-[11px] font-medium opacity-80 mt-1">Notify suppliers about upcoming settlement.</p>
                   </div>
                   <div className="bg-white/20 p-2 rounded-xl">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                   </div>
                </div>
                <div className="mt-6 flex gap-2">
                   <button 
                    onClick={() => upcomingPayments.forEach(p => sendReminder(p))}
                    className="flex-1 bg-white text-amber-700 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all"
                   >
                     Notify All Suppliers
                   </button>
                </div>
             </div>
           )}
           
           <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                 <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Pending Bills</p>
                 <p className="text-xl font-black text-gray-800 mt-1">
                   ৳{purchases.reduce((acc, p) => acc + p.costPrice, 0).toLocaleString()}
                 </p>
              </div>
              <div className="bg-red-50 p-5 rounded-3xl border border-red-100 shadow-sm">
                 <p className="text-[8px] font-black text-red-500 uppercase tracking-widest">Total Overdue</p>
                 <p className="text-xl font-black text-red-600 mt-1">
                   {purchases.filter(p => isOverdue(p.dueDate)).length} Items
                 </p>
              </div>
           </div>
        </div>

        <form onSubmit={handleAdd} className="bg-white p-8 rounded-[3rem] border border-gray-100 shadow-2xl space-y-6 mb-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -mr-16 -mt-16 opacity-50"></div>
          
          <div className="space-y-6 relative z-10">
            <div>
               <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2 ml-2">Select Medicine</label>
               <select 
                 required
                 value={medId} 
                 onChange={e => setMedId(e.target.value)} 
                 className="w-full bg-gray-50 rounded-[1.5rem] px-6 py-4 text-sm font-bold outline-none border-2 border-transparent focus:border-emerald-500/20 focus:bg-white transition-all"
               >
                  <option value="">Choose item...</option>
                  {medicines.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
               </select>
            </div>
            
            <div>
               <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2 ml-2">Select Supplier</label>
               <select 
                 required
                 value={supId} 
                 onChange={e => setSupId(e.target.value)} 
                 className="w-full bg-gray-50 rounded-[1.5rem] px-6 py-4 text-sm font-bold outline-none border-2 border-transparent focus:border-emerald-500/20 focus:bg-white transition-all"
               >
                  <option value="">Choose supplier...</option>
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
               </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="bg-gray-50 p-6 rounded-[2rem] border border-transparent focus-within:border-emerald-500/20 focus-within:bg-white transition-all">
                  <label className="text-[9px] font-black text-emerald-600 uppercase tracking-widest block mb-2">Purchase Qty</label>
                  <input 
                    required
                    type="number" 
                    placeholder="0" 
                    className="w-full bg-transparent text-2xl font-black text-gray-800 outline-none placeholder:text-gray-300" 
                    value={qty} 
                    onChange={e => setQty(e.target.value)} 
                  />
                  <p className="text-[8px] text-gray-400 font-bold mt-1 uppercase">Units to add</p>
               </div>
               
               <div className="bg-gray-50 p-6 rounded-[2rem] border border-transparent focus-within:border-emerald-500/20 focus-within:bg-white transition-all">
                  <label className="text-[9px] font-black text-emerald-600 uppercase tracking-widest block mb-2">Total Cost</label>
                  <div className="flex items-center gap-1">
                    <span className="text-xl font-black text-gray-300">৳</span>
                    <input 
                      required
                      type="number" 
                      placeholder="0.00" 
                      className="w-full bg-transparent text-2xl font-black text-gray-800 outline-none placeholder:text-gray-300" 
                      value={cost} 
                      onChange={e => setCost(e.target.value)} 
                    />
                  </div>
                  <p className="text-[8px] text-gray-400 font-bold mt-1 uppercase">Total bill paid</p>
               </div>
            </div>

            <div>
               <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2 ml-2">Payment Due Date</label>
               <input 
                 required
                 type="date"
                 value={dueDate} 
                 onChange={e => setDueDate(e.target.value)} 
                 className="w-full bg-gray-50 rounded-[1.5rem] px-6 py-4 text-sm font-bold outline-none border-2 border-transparent focus:border-emerald-500/20 focus:bg-white transition-all"
               />
               <p className="text-[8px] text-gray-400 font-bold mt-1 uppercase ml-2">Deadline for supplier payment</p>
            </div>
          </div>
          
          <button type="submit" className="w-full bg-emerald-600 text-white py-6 rounded-[2rem] font-black text-[11px] uppercase tracking-[0.4em] active:scale-95 transition-all shadow-xl shadow-emerald-500/20 relative z-10">
            Confirm Stock-In
          </button>
        </form>

        <div className="flex justify-between items-center mb-6 px-2">
           <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Recent Purchases</h3>
           <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">Audit Ready</span>
        </div>

        <div className="space-y-4">
          {purchases.slice().reverse().map(p => {
            const nearDue = isNearDue(p.dueDate);
            const overdue = isOverdue(p.dueDate);
            const supplier = suppliers.find(s => s.id === p.supplierId);
            
            return (
              <div key={p.id} className="bg-white p-6 rounded-[2.5rem] border border-gray-50 shadow-sm flex flex-col group hover:border-emerald-100 transition-all">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-black text-sm group-hover:scale-110 transition-transform">
                       IN
                    </div>
                    <div>
                      <p className="font-black text-gray-800 text-sm leading-tight">{p.medicineName}</p>
                      <p className="text-[10px] text-gray-400 font-bold mt-1">{new Date(p.date).toLocaleDateString()} • Ref: #{p.id.slice(-4)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-base font-black text-emerald-600">+{p.quantity} Units</p>
                    <p className="text-[10px] text-gray-400 font-black tracking-tighter">Cost: ৳{p.costPrice.toLocaleString()}</p>
                  </div>
                </div>

                {/* Due Date & Action Section */}
                <div className={`mt-4 p-4 rounded-2xl flex justify-between items-center ${overdue ? 'bg-red-50' : nearDue ? 'bg-amber-50' : 'bg-gray-50'}`}>
                  <div className="flex items-center gap-2">
                    <svg className={`w-4 h-4 ${overdue ? 'text-red-500' : nearDue ? 'text-amber-500' : 'text-gray-300'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <div className="flex flex-col">
                       <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Payment Due</span>
                       <span className={`text-[11px] font-black ${overdue ? 'text-red-600' : nearDue ? 'text-amber-600' : 'text-gray-600'}`}>
                        {new Date(p.dueDate).toLocaleDateString()} {overdue ? '(Overdue)' : nearDue ? '(Near Due)' : ''}
                      </span>
                    </div>
                  </div>
                  
                  {(overdue || nearDue) && supplier && (
                    <button 
                      onClick={() => sendReminder(p)}
                      className="bg-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm border border-gray-100 flex items-center gap-2 text-emerald-600 active:scale-95 transition-all"
                    >
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                      Notify SMS
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {purchases.length === 0 && (
             <div className="py-24 text-center bg-gray-50 rounded-[3rem] border-2 border-dashed border-gray-100">
                <p className="text-xs text-gray-300 font-black uppercase tracking-widest">No inward stock logged</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PurchaseManager;
