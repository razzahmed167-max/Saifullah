
import React, { useState, useEffect } from 'react';
import { Medicine, SaleItem, Customer, SaleRecord } from '../types';
import { LOYALTY_RULES } from '../constants';
import { getComplementarySuggestions } from '../services/geminiService';

interface SalesPOSProps {
  medicines: Medicine[];
  customers: Customer[];
  onCompleteSale: (items: SaleItem[], customerId?: string, pointsRedeemed?: number, manualDiscountPercent?: number) => void;
}

const getLevenshteinDistance = (a: string, b: string): number => {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
    }
  }
  return matrix[a.length][b.length];
};

const fuzzyMatch = (query: string, target: string): boolean => {
  const q = query.toLowerCase().trim();
  const t = target.toLowerCase().trim();
  if (!q) return true;
  if (t.includes(q)) return true;
  const queryTokens = q.split(/\s+/);
  const targetTokens = t.split(/\s+/);
  return queryTokens.every(qToken => {
    return targetTokens.some(tToken => {
      if (tToken.includes(qToken)) return true;
      if (qToken.length >= 3) {
        const distance = getLevenshteinDistance(qToken, tToken);
        const threshold = qToken.length > 6 ? 2 : 1;
        if (distance <= threshold) return true;
      }
      return false;
    });
  });
};

const SalesPOS: React.FC<SalesPOSProps> = ({ medicines, customers, onCompleteSale }) => {
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [search, setSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [redeemPoints, setRedeemPoints] = useState(false);
  const [manualDiscount, setManualDiscount] = useState<number>(0);
  const [aiSuggestions, setAiSuggestions] = useState<Medicine[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const filteredMedicines = medicines.filter(m => 
    m.stock > 0 && (fuzzyMatch(search, m.name) || fuzzyMatch(search, m.genericName))
  ).slice(0, 10);

  const filteredCustomers = customers.filter(c => 
    fuzzyMatch(customerSearch, c.name) || customerSearch === '' || c.phone.includes(customerSearch)
  ).slice(0, 5);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (cart.length > 0) {
        setIsAiLoading(true);
        const suggestedIds = await getComplementarySuggestions(cart, medicines);
        const suggestedMeds = medicines.filter(m => suggestedIds.includes(m.id));
        setAiSuggestions(suggestedMeds);
        setIsAiLoading(false);
      } else {
        setAiSuggestions([]);
      }
    };
    const timer = setTimeout(fetchSuggestions, 800);
    return () => clearTimeout(timer);
  }, [cart, medicines]);

  const addToCart = (med: Medicine) => {
    setCart(prev => {
      const existing = prev.find(item => item.medicineId === med.id);
      if (existing) {
        if (existing.quantity >= med.stock) {
          alert(`Only ${med.stock} units available.`);
          return prev;
        }
        return prev.map(item => 
          item.medicineId === med.id ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.pricePerUnit } : item
        );
      }
      return [...prev, {
        medicineId: med.id,
        name: med.name,
        quantity: 1,
        pricePerUnit: med.price,
        total: med.price
      }];
    });
    setSearch('');
  };

  const updateQuantity = (id: string, delta: number) => {
    const med = medicines.find(m => m.id === id);
    if (!med) return;
    setCart(prev => prev.map(item => {
      if (item.medicineId === id) {
        const newQty = Math.max(0, item.quantity + delta);
        if (newQty > med.stock) {
          alert(`Insufficient stock.`);
          return item;
        }
        return { ...item, quantity: newQty, total: newQty * item.pricePerUnit };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.medicineId !== id));
  };

  const subtotal = cart.reduce((acc, curr) => acc + curr.total, 0);
  const pointsDiscount = redeemPoints && selectedCustomer ? Math.min(subtotal, selectedCustomer.points / 10) : 0;
  const discountAmount = (subtotal * manualDiscount) / 100;
  const total = Math.max(0, subtotal - pointsDiscount - discountAmount);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    onCompleteSale(cart, selectedCustomer?.id, redeemPoints ? (selectedCustomer?.points || 0) : 0, manualDiscount);
    setCart([]);
    setSelectedCustomer(null);
    setRedeemPoints(false);
    setManualDiscount(0);
    alert('Sale completed!');
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 pb-20">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-30">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Sales POS</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">Terminal Active</p>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
        {/* Customer Search */}
        <section className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Customer</h3>
          {selectedCustomer ? (
            <div className="flex justify-between items-center bg-emerald-50 p-4 rounded-2xl border border-emerald-100 animate-in zoom-in duration-200">
              <div>
                <p className="text-sm font-black text-emerald-900">{selectedCustomer.name}</p>
                <p className="text-[10px] text-emerald-600 font-bold">{selectedCustomer.phone}</p>
              </div>
              <button onClick={() => setSelectedCustomer(null)} className="text-red-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          ) : (
            <input 
              type="text" 
              placeholder="Search customer..."
              className="w-full bg-gray-50 rounded-2xl px-5 py-3 text-sm font-bold outline-none"
              value={customerSearch}
              onChange={e => setCustomerSearch(e.target.value)}
            />
          )}
        </section>

        {/* Medicine Search */}
        <section className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Add Items</h3>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search medicine..."
              className="w-full bg-gray-50 rounded-2xl px-12 py-4 text-sm font-bold outline-none"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <svg className="w-5 h-5 absolute left-4 top-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            {search && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl border border-gray-100 shadow-2xl z-40 overflow-hidden animate-in fade-in slide-in-from-top-2">
                {filteredMedicines.map(m => (
                  <button key={m.id} onClick={() => addToCart(m)} className="w-full p-4 text-left hover:bg-emerald-50 flex justify-between border-b border-gray-50">
                    <div>
                      <p className="text-sm font-black text-gray-800">{m.name}</p>
                      <p className="text-[9px] text-gray-400 uppercase">{m.genericName}</p>
                    </div>
                    <p className="text-sm font-black text-emerald-600">৳{m.price}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Cart Items with Animation */}
        <section className="space-y-3">
          {cart.map(item => (
            <div 
              key={item.medicineId} 
              className="bg-white p-5 rounded-[2.5rem] border border-gray-50 shadow-sm flex justify-between items-center animate-in fade-in zoom-in-95 duration-300"
            >
              <div className="flex-1">
                <h4 className="font-black text-gray-800 text-sm">{item.name}</h4>
                <p className="text-[10px] text-emerald-600 font-bold">৳{item.pricePerUnit} / unit</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center bg-gray-50 rounded-xl p-1">
                  <button onClick={() => updateQuantity(item.medicineId, -1)} className="w-8 h-8 flex items-center justify-center text-gray-400">-</button>
                  <span className="w-6 text-center text-xs font-black">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.medicineId, 1)} className="w-8 h-8 flex items-center justify-center text-gray-400">+</button>
                </div>
                <p className="text-sm font-black text-gray-900 w-16 text-right">৳{item.total}</p>
                <button onClick={() => removeFromCart(item.medicineId)} className="text-red-300 hover:text-red-500 transition-colors ml-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            </div>
          ))}
          {cart.length === 0 && (
            <div className="py-20 text-center text-gray-300 border-2 border-dashed border-gray-100 rounded-[3rem]">
              <p className="text-[10px] font-black uppercase tracking-widest">Your cart is empty</p>
            </div>
          )}
        </section>
      </div>

      <footer className="bg-white border-t border-gray-100 p-6 shadow-2xl space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Payable</p>
            <p className="text-3xl font-black text-gray-900 transition-all duration-300">৳{total.toLocaleString()}</p>
          </div>
          <button 
            disabled={cart.length === 0}
            onClick={handleCheckout}
            className="bg-emerald-600 text-white px-10 py-5 rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-100 active:scale-95 disabled:opacity-30 transition-all"
          >
            Pay Now
          </button>
        </div>
      </footer>
    </div>
  );
};

export default SalesPOS;
