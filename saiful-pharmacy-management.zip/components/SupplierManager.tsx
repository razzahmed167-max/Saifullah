
import React, { useState } from 'react';
import { Supplier } from '../types';

interface SupplierManagerProps {
  suppliers: Supplier[];
  onAddSupplier: (s: Omit<Supplier, 'id'>) => void;
  onDeleteSupplier?: (id: string) => void;
}

const SupplierManager: React.FC<SupplierManagerProps> = ({ suppliers, onAddSupplier, onDeleteSupplier }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [addr, setAddr] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [search, setSearch] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !contactPerson) return;
    onAddSupplier({ 
      name, 
      phone, 
      address: addr,
      contactPerson,
      email,
      paymentTerms
    });
    setName(''); setPhone(''); setAddr(''); setContactPerson(''); setEmail(''); setPaymentTerms('');
    setIsFormOpen(false);
  };

  const filteredSuppliers = suppliers.filter(s => 
    s.name.toLowerCase().includes(search.toLowerCase()) || 
    s.contactPerson.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center sticky top-0 z-20">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tight">Suppliers</h2>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Vendor Database</p>
        </div>
        <button 
          onClick={() => setIsFormOpen(!isFormOpen)}
          className={`p-3 rounded-2xl shadow-lg transition-all active:scale-95 ${isFormOpen ? 'bg-red-50 text-red-500' : 'bg-emerald-600 text-white shadow-emerald-50'}`}
        >
          {isFormOpen ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
          )}
        </button>
      </header>

      <div className="p-4">
        {isFormOpen && (
          <form onSubmit={handleAdd} className="bg-white p-6 rounded-[2.5rem] border border-emerald-100 shadow-xl shadow-emerald-50 space-y-4 mb-8 animate-in slide-in-from-top duration-300">
            <h3 className="text-xs font-black text-emerald-600 uppercase tracking-widest mb-2 px-1">Register New Vendor</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1.5 ml-1">Company Details</label>
                <input 
                  placeholder="Supplier Name (e.g. Square Pharmaceuticals)" 
                  className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                  value={name} 
                  onChange={e => setName(e.target.value)} 
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <input 
                  placeholder="Contact Number" 
                  className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-xs font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                  value={phone} 
                  onChange={e => setPhone(e.target.value)} 
                  required
                />
                <input 
                  placeholder="Email Address" 
                  type="email"
                  className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-xs font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                  value={email} 
                  onChange={e => setEmail(e.target.value)} 
                />
              </div>

              <div>
                <label className="text-[9px] font-black text-emerald-600 uppercase tracking-widest block mb-1.5 ml-1">Key Contact Person</label>
                <div className="relative">
                  <input 
                    placeholder="Full Name (e.g. Mr. S.K. Saha)" 
                    className="w-full bg-emerald-50/50 rounded-2xl px-12 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                    value={contactPerson} 
                    onChange={e => setContactPerson(e.target.value)} 
                    required
                  />
                  <div className="absolute left-4 top-3.5 text-emerald-600">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                  </div>
                </div>
              </div>

              <input 
                placeholder="Office Address" 
                className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                value={addr} 
                onChange={e => setAddr(e.target.value)} 
              />

              <select 
                value={paymentTerms} 
                onChange={e => setPaymentTerms(e.target.value)}
                className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500 text-gray-500"
              >
                <option value="">Select Payment Terms...</option>
                <option value="Cash on Delivery">Cash on Delivery</option>
                <option value="Net 15">Net 15 Days</option>
                <option value="Net 30">Net 30 Days</option>
                <option value="Advance">Advance Payment</option>
              </select>
            </div>

            <button type="submit" className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-xl shadow-emerald-50 mt-4">
              Add Supplier to Database
            </button>
          </form>
        )}

        <div className="relative mb-6">
          <input 
            type="text" 
            placeholder="Search vendors or contact persons..."
            className="w-full bg-white border border-gray-100 rounded-2xl px-5 py-4 pl-12 shadow-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <svg className="w-5 h-5 absolute left-4 top-4.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {filteredSuppliers.map(s => (
            <div key={s.id} className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-bl-[3.5rem] -mr-8 -mt-8 transition-colors group-hover:bg-emerald-100"></div>
              
              <div className="relative">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-black text-gray-800 text-base leading-tight mb-1">{s.name}</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-emerald-600 font-black uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-lg">Verified Vendor</span>
                    </div>
                  </div>
                  {onDeleteSupplier && (
                    <button onClick={() => onDeleteSupplier(s.id)} className="p-2 text-gray-300 hover:text-red-500 transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  )}
                </div>

                {/* Primary Contact Area */}
                <div className="bg-emerald-50/30 rounded-2xl p-4 mb-4 border border-emerald-50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center text-emerald-600 border border-emerald-100">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                    </div>
                    <div>
                      <p className="text-[9px] text-emerald-600 font-black uppercase tracking-widest">Primary Contact Person</p>
                      <p className="text-sm font-black text-gray-800">{s.contactPerson}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 mb-4 px-1">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-gray-50 flex items-center justify-center text-gray-400">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                    </div>
                    <div>
                      <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest">Phone</p>
                      <p className="text-xs font-bold text-gray-700">{s.phone}</p>
                    </div>
                  </div>

                  {s.email && (
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-gray-50 flex items-center justify-center text-gray-400">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                      </div>
                      <div>
                        <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest">Email</p>
                        <p className="text-xs font-bold text-gray-700">{s.email}</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-gray-50 flex justify-between items-end">
                   <div>
                      <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest">Address</p>
                      <p className="text-[10px] text-gray-500 italic max-w-[150px]">{s.address || 'Not set'}</p>
                   </div>
                   {s.paymentTerms && (
                      <div className="text-right">
                         <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest">Terms</p>
                         <p className="text-[10px] font-black text-emerald-600">{s.paymentTerms}</p>
                      </div>
                   )}
                </div>
              </div>
            </div>
          ))}
          {filteredSuppliers.length === 0 && (
             <div className="text-center py-20 bg-gray-50 rounded-[2.5rem] border border-gray-100">
                <p className="text-xs font-black text-gray-300 uppercase tracking-widest">No matching suppliers found</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SupplierManager;
