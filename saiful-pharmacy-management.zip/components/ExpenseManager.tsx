
import React, { useState } from 'react';
import { Expense } from '../types';

interface ExpenseManagerProps {
  expenses: Expense[];
  onAddExpense: (ex: Omit<Expense, 'id' | 'date'>) => void;
}

const ExpenseManager: React.FC<ExpenseManagerProps> = ({ expenses, onAddExpense }) => {
  const [category, setCategory] = useState<Expense['category']>('Others');
  const [amount, setAmount] = useState('');
  const [desc, setDesc] = useState('');

  const categories: Expense['category'][] = ['Rent', 'Electricity', 'Salary', 'Transport', 'Others'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount) return;
    onAddExpense({ category, amount: Number(amount), description: desc });
    setAmount('');
    setDesc('');
  };

  const totalMonthlyExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tight">Expenses</h2>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Shop Maintenance Logs</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] font-black text-pink-500 uppercase tracking-widest">Total Outflow</p>
          <p className="text-xl font-black text-pink-600 leading-none">৳{totalMonthlyExpenses}</p>
        </div>
      </header>

      <div className="p-4">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-4 mb-8">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1 block">Category</label>
              <select 
                value={category} 
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-gray-50 rounded-2xl px-4 py-3 text-xs font-bold outline-none border-none focus:ring-2 focus:ring-pink-500"
              >
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1 block">Amount (৳)</label>
              <input 
                required 
                type="number" 
                placeholder="0.00"
                className="w-full bg-gray-50 rounded-2xl px-4 py-3 text-xs font-bold outline-none border-none focus:ring-2 focus:ring-pink-500"
                value={amount}
                onChange={e => setAmount(e.target.value)}
              />
            </div>
          </div>
          <input 
            placeholder="Expense Details (e.g. Shop rent for January)" 
            className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-xs font-bold outline-none border-none focus:ring-2 focus:ring-pink-500"
            value={desc}
            onChange={e => setDesc(e.target.value)}
          />
          <button type="submit" className="w-full bg-pink-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-xl shadow-pink-50">Log Expense</button>
        </form>

        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 px-1">Recent Outflows</h3>
        <div className="space-y-3">
          {expenses.slice().reverse().map(ex => (
            <div key={ex.id} className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center font-black text-xs">
                  {ex.category[0]}
                </div>
                <div>
                  <p className="font-bold text-gray-900 text-xs">{ex.category}</p>
                  <p className="text-[9px] text-gray-400 font-bold uppercase">{ex.date.split('T')[0]}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-red-500">-৳{ex.amount}</p>
                <p className="text-[9px] text-gray-400 font-bold max-w-[100px] truncate">{ex.description}</p>
              </div>
            </div>
          ))}
          {expenses.length === 0 && <p className="text-center text-xs text-gray-400 italic py-12">No expenses logged yet.</p>}
        </div>
      </div>
    </div>
  );
};

export default ExpenseManager;
