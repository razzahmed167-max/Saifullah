
import React, { useState } from 'react';
import { SaleRecord } from '../types';

interface TransactionHistoryProps {
  sales: SaleRecord[];
  onReturnSale?: (id: string) => void;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ sales, onReturnSale }) => {
  const [selectedSale, setSelectedSale] = useState<SaleRecord | null>(null);

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-10">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Sales History</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Full Transaction Log</p>
      </header>

      <div className="p-4 space-y-3">
        {sales.slice().reverse().map(sale => (
          <div 
            key={sale.id} 
            onClick={() => setSelectedSale(sale)}
            className={`bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm active:scale-[0.98] transition-all cursor-pointer relative overflow-hidden ${sale.status === 'returned' ? 'bg-red-50/30 opacity-70' : ''}`}
          >
             {sale.status === 'returned' && (
               <div className="absolute top-0 right-0 bg-red-500 text-white text-[8px] font-black uppercase px-3 py-1 rounded-bl-xl">Returned</div>
             )}
             <div className="flex justify-between items-start mb-3">
                <div>
                   <p className="text-[10px] font-black text-emerald-600 uppercase">INV #{sale.id}</p>
                   <p className="text-[9px] text-gray-400 font-bold mt-0.5">{new Date(sale.date).toLocaleString()}</p>
                </div>
                <p className={`font-black ${sale.status === 'returned' ? 'text-gray-400 line-through' : 'text-gray-800'}`}>
                  ৳{sale.totalAmount.toLocaleString()}
                </p>
             </div>
             <div className="space-y-1">
                {sale.items.slice(0, 2).map((item, idx) => (
                   <p key={idx} className="text-[10px] text-gray-500 flex justify-between">
                      <span>{item.name} x {item.quantity}</span>
                      <span className="font-bold">৳{item.total}</span>
                   </p>
                ))}
                {sale.items.length > 2 && <p className="text-[9px] text-emerald-500 font-bold">+ {sale.items.length - 2} more items</p>}
             </div>
          </div>
        ))}
        {sales.length === 0 && (
          <div className="py-20 text-center text-gray-300">
            <svg className="w-12 h-12 mx-auto mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
            <p className="text-xs font-black uppercase tracking-widest">No history found</p>
          </div>
        )}
      </div>

      {/* Invoice Details Modal */}
      {selectedSale && (
        <div className="fixed inset-0 z-[100] bg-gray-900/60 backdrop-blur-sm flex items-end justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-8 animate-in slide-in-from-bottom duration-300 max-h-[90vh] overflow-y-auto no-scrollbar">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black text-gray-800">Invoice Details</h3>
                <button onClick={() => setSelectedSale(null)} className="p-2 bg-gray-50 rounded-full">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
             </div>

             <div className="space-y-6">
                <div className="flex justify-between pb-4 border-b border-gray-50">
                   <div>
                      <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Transaction ID</p>
                      <p className="text-sm font-black text-gray-800">#{selectedSale.id}</p>
                   </div>
                   <div className="text-right">
                      <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Date</p>
                      <p className="text-sm font-black text-gray-800">{new Date(selectedSale.date).toLocaleDateString()}</p>
                   </div>
                </div>

                <div className="space-y-3">
                   <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Items Sold</p>
                   {selectedSale.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl">
                         <div>
                            <p className="text-xs font-black text-gray-800">{item.name}</p>
                            <p className="text-[10px] text-gray-400">Rate: ৳{item.pricePerUnit} x {item.quantity}</p>
                         </div>
                         <p className="text-sm font-black text-gray-800">৳{item.total}</p>
                      </div>
                   ))}
                </div>

                <div className="pt-4 space-y-2">
                   <div className="flex justify-between text-xs text-gray-500 font-bold">
                      <span>Subtotal</span>
                      <span>৳{(selectedSale.totalAmount + (selectedSale.discountAmount || 0)).toLocaleString()}</span>
                   </div>
                   {selectedSale.discountAmount && (
                      <div className="flex justify-between text-xs text-emerald-600 font-bold">
                         <span>Discount</span>
                         <span>-৳{selectedSale.discountAmount}</span>
                      </div>
                   )}
                   <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                      <p className="text-sm font-black text-gray-800 uppercase tracking-widest">Grand Total</p>
                      <p className="text-2xl font-black text-emerald-600">৳{selectedSale.totalAmount.toLocaleString()}</p>
                   </div>
                </div>

                <div className="flex gap-3 pt-4">
                   <button 
                     onClick={() => { window.print(); }} 
                     className="flex-1 bg-gray-900 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all"
                   >
                     Print Invoice
                   </button>
                   {selectedSale.status === 'completed' && onReturnSale && (
                      <button 
                        onClick={() => {
                          if (confirm('Are you sure you want to return this order? Stock will be restored.')) {
                            onReturnSale(selectedSale.id);
                            setSelectedSale(null);
                          }
                        }}
                        className="bg-red-50 text-red-500 px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all border border-red-100"
                      >
                        Return
                      </button>
                   )}
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionHistory;
