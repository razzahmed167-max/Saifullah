
import React from 'react';
import { SaleRecord } from '../types';

interface ReturnsManagerProps {
  sales: SaleRecord[];
}

const ReturnsManager: React.FC<ReturnsManagerProps> = ({ sales }) => {
  const returnedSales = sales.filter(s => s.status === 'returned').slice().reverse();

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-20">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Returns Audit</h2>
        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Returned Medicines History</p>
      </header>

      <div className="p-4 space-y-4">
        {returnedSales.map(sale => (
          <div key={sale.id} className="bg-white p-6 rounded-[2.5rem] border border-red-50 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 bg-red-500 text-white text-[8px] font-black uppercase px-4 py-1 rounded-bl-xl">Returned</div>
             
             <div className="flex justify-between items-start mb-4">
                <div>
                   <p className="text-[10px] font-black text-red-600 uppercase">INV #{sale.id}</p>
                   <p className="text-[9px] text-gray-400 font-bold">Returned on: {sale.returnDate ? new Date(sale.returnDate).toLocaleDateString() : 'N/A'}</p>
                </div>
                <p className="text-sm font-black text-gray-400 line-through">৳{sale.totalAmount.toLocaleString()}</p>
             </div>

             <div className="space-y-2 bg-gray-50/50 p-4 rounded-2xl">
                {sale.items.map((item, idx) => (
                   <div key={idx} className="flex justify-between items-center text-[10px]">
                      <span className="text-gray-600 font-bold">{item.name} x {item.quantity}</span>
                      <span className="text-gray-400">Restored to Stock</span>
                   </div>
                ))}
             </div>
             
             <div className="mt-4 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                <p className="text-[9px] font-black text-emerald-600 uppercase tracking-widest">Stock Re-entry Verified</p>
             </div>
          </div>
        ))}

        {returnedSales.length === 0 && (
          <div className="py-24 text-center">
             <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
             </div>
             <p className="text-xs font-black text-gray-300 uppercase tracking-widest">No returns recorded</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReturnsManager;
