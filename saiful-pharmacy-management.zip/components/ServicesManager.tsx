
import React, { useState } from 'react';
import { ServiceRecord } from '../types';

interface ServicesManagerProps {
  records: ServiceRecord[];
  onAddRecord: (rec: Omit<ServiceRecord, 'id' | 'date'>) => void;
}

const ServicesManager: React.FC<ServicesManagerProps> = ({ records, onAddRecord }) => {
  const [type, setType] = useState<'Recharge' | 'bKash' | 'Nagad'>('Recharge');
  const [amount, setAmount] = useState('');
  const [commission, setCommission] = useState('');
  const [desc, setDesc] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddRecord({ type, amount: Number(amount), commission: Number(commission), description: desc });
    setAmount('');
    setCommission('');
    setDesc('');
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tight">Digital Services</h2>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Log Commissions & Volume</p>
        </div>
      </header>

      <div className="p-4">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-4 mb-8">
          <div className="flex gap-2">
            {(['Recharge', 'bKash', 'Nagad'] as const).map(t => (
              <button 
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${type === t ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-100' : 'bg-gray-50 text-gray-400 border-gray-100'}`}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <input required type="number" placeholder="Volume Amount" className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500" value={amount} onChange={e => setAmount(e.target.value)} />
            <input required type="number" placeholder="Commission (৳)" className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500" value={commission} onChange={e => setCommission(e.target.value)} />
          </div>
          <input placeholder="Transaction Details (Optional)" className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none focus:ring-2 focus:ring-emerald-500" value={desc} onChange={e => setDesc(e.target.value)} />
          <button type="submit" className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-xl shadow-emerald-50">Log Service Entry</button>
        </form>

        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 px-1">Recent Logs</h3>
        <div className="space-y-3">
          {records.slice().reverse().map(rec => (
            <div key={rec.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm ${rec.type === 'bKash' ? 'bg-pink-50 text-pink-600' : rec.type === 'Nagad' ? 'bg-orange-50 text-orange-600' : 'bg-blue-50 text-blue-600'}`}>
                  {rec.type[0]}
                </div>
                <div>
                  <p className="font-bold text-gray-900 text-xs">{rec.type} Transaction</p>
                  <p className="text-[9px] text-gray-400 font-bold uppercase">{rec.date.split('T')[0]}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-emerald-600">+৳{rec.commission}</p>
                <p className="text-[9px] text-gray-400 font-bold">Vol: ৳{rec.amount}</p>
              </div>
            </div>
          ))}
          {records.length === 0 && <p className="text-center text-xs text-gray-400 italic py-12">No service records yet.</p>}
        </div>
      </div>
    </div>
  );
};

export default ServicesManager;
