
import React, { useState } from 'react';
import { Medicine } from '../types';
import { GoogleGenAI, Type, FunctionDeclaration } from '@google/genai';

interface InventoryManagerProps {
  medicines: Medicine[];
  onAddMedicine: (med: Omit<Medicine, 'id'>) => void;
  onUpdateMedicine: (id: string, updates: Partial<Medicine>) => void;
}

/**
 * Levenshtein distance algorithm for typo tolerance
 */
const getLevenshteinDistance = (a: string, b: string): number => {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,      // deletion
        matrix[i][j - 1] + 1,      // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );
    }
  }
  return matrix[a.length][b.length];
};

/**
 * Enhanced Fuzzy Match:
 * 1. Exact substring match
 * 2. Tokenized match (every query word must match a target word)
 * 3. Typo-forgiving Levenshtein check
 */
const fuzzyMatch = (query: string, target: string): boolean => {
  const q = query.toLowerCase().trim();
  const t = target.toLowerCase().trim();
  if (!q) return true;
  
  // Direct substring check (fast path)
  if (t.includes(q)) return true;

  const queryTokens = q.split(/\s+/);
  const targetTokens = t.split(/\s+/);

  // Every token in the query must be found in the target (fuzzily)
  return queryTokens.every(qToken => {
    return targetTokens.some(tToken => {
      // 1. Prefix/Substring match
      if (tToken.includes(qToken)) return true;

      // 2. Subsequence match
      let i = 0, j = 0;
      while (i < qToken.length && j < tToken.length) {
        if (qToken[i] === tToken[j]) i++;
        j++;
      }
      if (i === qToken.length) return true;

      // 3. Typo tolerance (Levenshtein)
      // Allow 1 typo for 3-5 chars, 2 typos for 6+ chars
      if (qToken.length >= 3) {
        const distance = getLevenshteinDistance(qToken, tToken);
        const threshold = qToken.length > 6 ? 2 : 1;
        if (distance <= threshold) return true;
      }

      return false;
    });
  });
};

const InventoryManager: React.FC<InventoryManagerProps> = ({ medicines, onAddMedicine, onUpdateMedicine }) => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [voiceFeedback, setVoiceFeedback] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showBulkActionModal, setShowBulkActionModal] = useState<'stock' | 'category' | null>(null);
  const [bulkValue, setBulkValue] = useState<string>('');

  const [newMed, setNewMed] = useState<Omit<Medicine, 'id'>>({
    name: '',
    genericName: '',
    category: '',
    price: 0,
    stock: 0,
    expiryDate: new Date().toISOString().split('T')[0],
    unit: 'tablet'
  });

  const today = new Date();
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(today.getDate() + 30);

  const setFilterFunction: FunctionDeclaration = {
    name: 'setInventoryFilter',
    parameters: {
      type: Type.OBJECT,
      description: 'Sets the inventory filter based on user request.',
      properties: {
        filterType: { 
          type: Type.STRING, 
          enum: ['all', 'low', 'near_expiry', 'expired'],
          description: 'The type of filter to apply to the medicine list.' 
        }
      },
      required: ['filterType']
    }
  };

  const handleVoiceCommand = async (text: string) => {
    setVoiceFeedback(`অপেক্ষা করুন...`);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `ইউজার বলেছে: "${text}"। এই কমান্ডের ভিত্তিতে ইনভেন্টরি ফিল্টার সেট করুন। (all, low, near_expiry, expired)`,
        config: {
          tools: [{ functionDeclarations: [setFilterFunction] }]
        }
      });

      if (response.functionCalls) {
        const fc = response.functionCalls[0];
        if (fc.name === 'setInventoryFilter') {
          const type = (fc.args as any).filterType;
          setFilter(type);
          const labels: Record<string, string> = {
            all: 'সবগুলো',
            low: 'কম স্টক',
            near_expiry: 'দ্রুত মেয়াদ শেষ হবে এমন',
            expired: 'মেয়াদোত্তীর্ণ'
          };
          setVoiceFeedback(`${labels[type]} ফিল্টার করা হয়েছে`);
          setTimeout(() => setVoiceFeedback(''), 3000);
        }
      } else {
        setVoiceFeedback('বুঝতে পারিনি, আবার চেষ্টা করুন');
        setTimeout(() => setVoiceFeedback(''), 3000);
      }
    } catch (error) {
      setVoiceFeedback('ত্রুটি হয়েছে');
      setTimeout(() => setVoiceFeedback(''), 3000);
    }
  };

  const startListening = () => {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) {
      alert("ভয়েস সাপোর্ট নেই।");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'bn-BD';
    recognition.onstart = () => { setIsListening(true); setVoiceFeedback('বলুন...'); };
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setVoiceFeedback(`শুনেছি: "${transcript}"`);
      handleVoiceCommand(transcript);
    };
    recognition.onerror = () => { setIsListening(false); setVoiceFeedback('ত্রুটি'); };
    recognition.onend = () => { setIsListening(false); };
    recognition.start();
  };

  const filteredItems = medicines.filter(m => {
    const matchesSearch = fuzzyMatch(searchTerm, m.name) || fuzzyMatch(searchTerm, m.genericName);
    if (!matchesSearch) return false;

    const expiryDate = new Date(m.expiryDate);
    if (filter === 'low') return m.stock < 100;
    if (filter === 'expired') return expiryDate < today;
    if (filter === 'near_expiry') return expiryDate >= today && expiryDate <= thirtyDaysFromNow;
    return true;
  });

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredItems.length && filteredItems.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredItems.map(m => m.id)));
    }
  };

  const handleBulkAction = () => {
    if (!showBulkActionModal) return;
    if (confirm(`Are you sure you want to update ${selectedIds.size} medicines?`)) {
      selectedIds.forEach(id => {
        if (showBulkActionModal === 'stock') {
          const med = medicines.find(m => m.id === id);
          if (med) onUpdateMedicine(id, { stock: Math.max(0, med.stock + Number(bulkValue)) });
        } else if (showBulkActionModal === 'category') {
          onUpdateMedicine(id, { category: bulkValue });
        }
      });
      setSelectedIds(new Set());
      setShowBulkActionModal(null);
      setBulkValue('');
    }
  };

  const getStatus = (item: Medicine) => {
    const exp = new Date(item.expiryDate);
    if (exp < today) return { label: 'Expired', color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-100' };
    if (item.stock < 100) return { label: 'Low Stock', color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-100' };
    if (exp <= thirtyDaysFromNow) return { label: 'Near Expiry', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100' };
    return { label: 'Healthy', color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100' };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMed.name || !newMed.price) return;
    onAddMedicine(newMed);
    setShowAddModal(false);
    setNewMed({
      name: '',
      genericName: '',
      category: '',
      price: 0,
      stock: 0,
      expiryDate: new Date().toISOString().split('T')[0],
      unit: 'tablet'
    });
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 sticky top-0 z-30">
        <div className="flex justify-between items-center mb-3">
          <div>
            <h2 className="text-xl font-black text-gray-800 tracking-tight">Inventory</h2>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">{medicines.length} Medicines Active</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={startListening}
              className={`w-12 h-12 rounded-2xl shadow-lg transition-all active:scale-90 flex items-center justify-center border ${isListening ? 'bg-red-500 text-white animate-pulse border-red-400' : 'bg-white text-gray-400 border-gray-100'}`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            </button>
            <button 
              onClick={() => setShowAddModal(true)}
              className="bg-emerald-600 text-white w-12 h-12 rounded-2xl shadow-xl shadow-emerald-50 flex items-center justify-center active:scale-95 transition-transform"
            >
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mt-4">
           <input 
             type="text"
             placeholder="Search inventory (Typos allowed)..."
             className="w-full bg-gray-50 border-2 border-transparent rounded-2xl px-12 py-3.5 text-sm font-bold focus:bg-white focus:border-emerald-600/20 outline-none transition-all shadow-inner"
             value={searchTerm}
             onChange={e => setSearchTerm(e.target.value)}
           />
           <svg className="w-5 h-5 absolute left-4 top-3.5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
           {searchTerm && (
             <button onClick={() => setSearchTerm('')} className="absolute right-4 top-3.5 text-gray-300 hover:text-gray-500">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
             </button>
           )}
        </div>
        
        {voiceFeedback && (
          <div className="bg-emerald-600 text-white text-[9px] font-black uppercase tracking-widest px-4 py-2 rounded-xl shadow-lg animate-in fade-in slide-in-from-top-1 mt-2">
            Voice: {voiceFeedback}
          </div>
        )}
      </header>

      {/* Filter Tabs & Select All */}
      <div className="p-4 flex items-center gap-4 overflow-x-auto no-scrollbar">
        <button 
          onClick={toggleSelectAll}
          className={`shrink-0 px-4 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${selectedIds.size > 0 ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white border-gray-100 text-gray-400'}`}
        >
          {selectedIds.size === filteredItems.length && filteredItems.length > 0 ? 'Deselect All' : `Select All (${selectedIds.size})`}
        </button>
        <div className="h-6 w-px bg-gray-200 shrink-0"></div>
        {['all', 'low', 'near_expiry', 'expired'].map(f => (
          <button 
            key={f}
            onClick={() => setFilter(f)}
            className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border whitespace-nowrap ${filter === f ? 'bg-gray-900 text-white border-gray-900 shadow-xl' : 'bg-white border-gray-100 text-gray-400'}`}
          >
            {f.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-4">
        {filteredItems.map(item => {
          const status = getStatus(item);
          const isSelected = selectedIds.has(item.id);
          return (
            <div 
              key={item.id} 
              onClick={() => toggleSelect(item.id)}
              className={`bg-white p-5 rounded-[2rem] border-2 transition-all active:scale-[0.98] group flex flex-col relative overflow-hidden cursor-pointer ${isSelected ? 'border-emerald-500 shadow-lg shadow-emerald-50' : 'border-transparent shadow-sm'}`}
            >
              {isSelected && (
                <div className="absolute top-4 left-4 z-10">
                   <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center shadow-md">
                      <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                   </div>
                </div>
              )}
              
              <div className={`flex justify-between items-start mb-4 ${isSelected ? 'pl-8' : ''}`}>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                     <h3 className="font-black text-gray-800 text-lg leading-tight tracking-tight">{item.name}</h3>
                     <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest border ${status.bg} ${status.color} ${status.border}`}>
                        {status.label}
                     </span>
                  </div>
                  <p className="text-[11px] text-gray-400 font-bold uppercase tracking-widest">{item.genericName}</p>
                  
                  {item.description && (
                    <div className="mt-2 pr-4 relative">
                       <p className="text-[11px] text-gray-500 italic leading-snug line-clamp-2">
                          <span className="text-emerald-500 font-black mr-1 text-[8px] tracking-widest uppercase">✨ AI INFO:</span>
                          {item.description}
                       </p>
                    </div>
                  )}
                </div>
                <div className="text-right ml-4">
                  <p className="text-2xl font-black text-gray-900 leading-none">৳{item.price}</p>
                  <p className={`text-[10px] font-black uppercase mt-1 ${item.stock < 100 ? 'text-orange-500' : 'text-gray-400'}`}>{item.stock} in Stock</p>
                </div>
              </div>
            </div>
          );
        })}
        {filteredItems.length === 0 && (
          <div className="py-20 text-center text-gray-300 italic">No medicines match your search/filters</div>
        )}
      </div>

      {/* Bulk Action Bar */}
      {selectedIds.size > 0 && (
        <div className="fixed bottom-20 left-4 right-4 z-40 animate-in slide-in-from-bottom duration-300">
           <div className="bg-gray-900 text-white p-4 rounded-3xl shadow-2xl flex items-center justify-between border border-white/10">
              <div className="px-2">
                 <p className="text-[10px] font-black uppercase opacity-50">Selected Items</p>
                 <p className="text-sm font-black text-emerald-400">{selectedIds.size} medicines</p>
              </div>
              <div className="flex gap-2">
                 <button onClick={() => setShowBulkActionModal('stock')} className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors">Stock</button>
                 <button onClick={() => setShowBulkActionModal('category')} className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors">Category</button>
                 <button onClick={() => setSelectedIds(new Set())} className="bg-red-500/20 text-red-400 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors">Cancel</button>
              </div>
           </div>
        </div>
      )}

      {/* Bulk Action Modals */}
      {showBulkActionModal && (
        <div className="fixed inset-0 z-[100] bg-gray-900/60 backdrop-blur-sm flex items-center justify-center p-6">
           <div className="bg-white w-full max-sm rounded-[2.5rem] p-8 animate-in zoom-in duration-200 shadow-2xl">
              <h3 className="text-xl font-black text-gray-800 mb-2">
                 {showBulkActionModal === 'stock' ? 'Adjust Stock Level' : 'Change Category'}
              </h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-6">Applying to {selectedIds.size} selected items</p>
              <div className="space-y-4 mb-8">
                 <input 
                   type={showBulkActionModal === 'stock' ? "number" : "text"} 
                   placeholder={showBulkActionModal === 'stock' ? "e.g. 50 or -20" : "New Category Name"} 
                   className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-xl font-black text-gray-800 outline-none focus:ring-2 focus:ring-emerald-500"
                   value={bulkValue}
                   onChange={e => setBulkValue(e.target.value)}
                   autoFocus
                 />
              </div>
              <div className="flex gap-3">
                 <button onClick={handleBulkAction} className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95">Confirm</button>
                 <button onClick={() => { setShowBulkActionModal(null); setBulkValue(''); }} className="flex-1 bg-gray-100 text-gray-400 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95">Cancel</button>
              </div>
           </div>
        </div>
      )}

      {/* Add Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] bg-gray-900/60 backdrop-blur-md flex items-end justify-center">
          <form onSubmit={handleSubmit} className="bg-white w-full max-w-md rounded-t-[3rem] p-10 space-y-4 animate-in slide-in-from-bottom duration-500 border-t-8 border-emerald-600">
             <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-black text-gray-900 tracking-tight">New Medicine</h2>
                <button type="button" onClick={() => setShowAddModal(false)} className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-200">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
             </div>
             
             <div className="space-y-3">
                <input required placeholder="Medicine Name" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.name} onChange={e => setNewMed({...newMed, name: e.target.value})} />
                <input placeholder="Generic Name" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.genericName} onChange={e => setNewMed({...newMed, genericName: e.target.value})} />
                <div className="grid grid-cols-2 gap-3">
                   <input required type="number" placeholder="Price (৳)" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.price || ''} onChange={e => setNewMed({...newMed, price: Number(e.target.value)})} />
                   <input required type="number" placeholder="Stock" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.stock || ''} onChange={e => setNewMed({...newMed, stock: Number(e.target.value)})} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                   <input required type="date" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.expiryDate} onChange={e => setNewMed({...newMed, expiryDate: e.target.value})} />
                   <select className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.unit} onChange={e => setNewMed({...newMed, unit: e.target.value as any})}>
                      <option value="tablet">Tablet</option>
                      <option value="capsule">Capsule</option>
                      <option value="syrup">Syrup</option>
                      <option value="injection">Injection</option>
                   </select>
                </div>
                <input placeholder="Category" className="w-full bg-gray-50 rounded-2xl px-6 py-4 text-sm font-bold border-2 border-transparent focus:border-emerald-600/20 focus:bg-white outline-none transition-all" value={newMed.category} onChange={e => setNewMed({...newMed, category: e.target.value})} />
             </div>
             <button type="submit" className="w-full bg-emerald-600 text-white py-5 rounded-[2rem] font-black text-xs uppercase tracking-widest shadow-2xl active:scale-95">Save to Inventory</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default InventoryManager;
