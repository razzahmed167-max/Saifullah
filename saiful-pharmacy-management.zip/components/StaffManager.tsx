
import React, { useState } from 'react';
import { Staff } from '../types';

interface StaffManagerProps {
  staff: Staff[];
  onAddStaff: (s: Omit<Staff, 'id' | 'joinDate'>) => void;
  onRemoveStaff: (id: string) => void;
}

const StaffManager: React.FC<StaffManagerProps> = ({ staff, onAddStaff, onRemoveStaff }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [phone, setPhone] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    onAddStaff({ name, role, phone });
    setName(''); setRole(''); setPhone('');
    setIsAdding(false);
  };

  return (
    <div className="pb-24">
      <header className="p-4 bg-white border-b border-gray-100 flex justify-between items-center sticky top-0 z-20">
        <div>
          <h2 className="text-xl font-black text-gray-800 tracking-tight">Staff Management</h2>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Pharmacy Team</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className={`p-3 rounded-2xl shadow-lg transition-all active:scale-95 ${isAdding ? 'bg-red-50 text-red-500' : 'bg-emerald-600 text-white shadow-emerald-50'}`}
        >
          {isAdding ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
          )}
        </button>
      </header>

      <div className="p-4">
        {isAdding && (
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-[2.5rem] border border-emerald-100 shadow-xl shadow-emerald-50 space-y-4 mb-8 animate-in slide-in-from-top duration-300">
            <h3 className="text-xs font-black text-emerald-600 uppercase tracking-widest mb-2 px-1">New Employee</h3>
            <div className="space-y-4">
              <input 
                placeholder="Employee Name" 
                className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                value={name} 
                onChange={e => setName(e.target.value)} 
                required
              />
              <input 
                placeholder="Job Role (e.g. Sales, Manager)" 
                className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                value={role} 
                onChange={e => setRole(e.target.value)} 
              />
              <input 
                placeholder="Phone Number" 
                className="w-full bg-gray-50 rounded-2xl px-5 py-3.5 text-sm font-bold outline-none border-none focus:ring-2 focus:ring-emerald-500" 
                value={phone} 
                onChange={e => setPhone(e.target.value)} 
                required
              />
            </div>
            <button type="submit" className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all">
              Save Member
            </button>
          </form>
        )}

        <div className="grid grid-cols-1 gap-4">
          {staff.map(member => (
            <div key={member.id} className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm flex justify-between items-center group relative overflow-hidden">
               <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-50 rounded-bl-[2.5rem] -mr-4 -mt-4 opacity-50"></div>
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center font-black text-lg">
                    {member.name[0]}
                  </div>
                  <div>
                    <h4 className="font-black text-gray-800 text-sm leading-tight">{member.name}</h4>
                    <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest mt-0.5">{member.role || 'Staff'}</p>
                    <p className="text-[10px] text-gray-400 font-medium mt-1">{member.phone}</p>
                  </div>
               </div>
               <button 
                 onClick={() => onRemoveStaff(member.id)}
                 className="p-2 text-gray-300 hover:text-red-500 transition-colors"
               >
                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
               </button>
            </div>
          ))}
          {staff.length === 0 && (
            <div className="text-center py-20 text-gray-300 font-bold uppercase tracking-widest italic">No staff members listed</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StaffManager;
